/*
 * ============================================================
 *  MODEL — Logica do jogo e estruturas de dados
 * ============================================================
 *  Bugs corrigidos:
 *  - BUG2: heapify_max usava < em vez de >
 *  - BUG3: graph_add_edge unidirecional na lista
 *  - BUG4: avl_insert sem checagem de NULL
 *
 *  Requisitos implementados:
 *  - M01: tempo dos 7 sorts
 *  - M02: ASCII da BST
 *  - M03/M05: contadores de rotacoes AVL
 *  - P01: persistencia em arquivo
 *  - P02: nome do jogador
 *  - P03: complexidade O() em todas as funcoes
 *  - P04: checagem de NULL em todo malloc
 *  - P06: relatorio final
 *
 *  Features adicionais:
 *  - Fruta bonus
 *  - Sistema de conquistas
 *  - Estatisticas BFS/DFS/Dijkstra
 *  - Velocidade dos fantasmas por nivel
 * ============================================================
 */

#include "pacman.h"

/* ============================================================
 *  MAPAS (28x31)
 * ============================================================ */

static const char *maps[MAP_COUNT][MAP_H] = {
    {
        "############################",
        "#............##............#",
        "#.####.#####.##.#####.####.#",
        "#o####.#####.##.#####.####o#",
        "#.####.#####.##.#####.####.#",
        "#..........................#",
        "#.####.##.########.##.####.#",
        "#.####.##.########.##.####.#",
        "#......##....##....##......#",
        "######.##### ## #####.######",
        "     #.##### ## #####.#     ",
        "     #.##          ##.#     ",
        "     #.## ###--### ##.#     ",
        "######.## #GGGGGG# ##.######",
        "T     .   #GGGGGG#   .     T",
        "######.## #GGGGGG# ##.######",
        "     #.## ######## ##.#     ",
        "     #.##          ##.#     ",
        "     #.## ######## ##.#     ",
        "######.## ######## ##.######",
        "#............##............#",
        "#.####.#####.##.#####.####.#",
        "#.####.#####.##.#####.####.#",
        "#o..##.......  .......##..o#",
        "###.##.##.########.##.##.###",
        "###.##.##.########.##.##.###",
        "#......##....##....##......#",
        "#.##########.##.##########.#",
        "#.##########.##.##########.#",
        "#..........................#",
        "############################"
    },
    {
        "############################",
        "#............##............#",
        "#.####.#####.##.#####.####.#",
        "#o..........................o",
        "#.####.#####.##.#####.####.#",
        "#..........................#",
        "#.####.##.########.##.####.#",
        "#......##....##....##......#",
        "#......##....##....##......#",
        "######.##### ## #####.######",
        "     #.##### ## #####.#     ",
        "     #.##          ##.#     ",
        "     #.## ###--### ##.#     ",
        "######.## #GGGGGG# ##.######",
        "T     .   #GGGGGG#   .     T",
        "######.## #GGGGGG# ##.######",
        "     #.## ######## ##.#     ",
        "     #.##          ##.#     ",
        "     #.## ######## ##.#     ",
        "######.## ######## ##.######",
        "#............##............#",
        "#.####.#####.##.#####.####.#",
        "#o..........................o",
        "#...##.......  .......##...#",
        "###.##.##.########.##.##.###",
        "###......................###",
        "#......##....##....##......#",
        "#.##########.##.##########.#",
        "#..........................#",
        "#..........................#",
        "############################"
    },
    {
        "############################",
        "#............##............#",
        "#.####.#####.##.#####.####.#",
        "#o####.#####.##.#####.####o#",
        "#..........................#",
        "##.####.##.######.##.####.##",
        " #.####.##.######.##.####.# ",
        "#......##....##....##......#",
        "#......##....##....##......#",
        "######.##### ## #####.######",
        "     #.##### ## #####.#     ",
        "     #.##          ##.#     ",
        "     #.## ###--### ##.#     ",
        "######.## #GGGGGG# ##.######",
        "T     .   #GGGGGG#   .     T",
        "######.## #GGGGGG# ##.######",
        "     #.## ######## ##.#     ",
        "     #.##          ##.#     ",
        "     #.## ######## ##.#     ",
        "######.## ######## ##.######",
        "#............##............#",
        "#.####.#####.##.#####.####.#",
        "#.####.#####.##.#####.####.#",
        "#o..##...............##..o#",
        "###.##.##.########.##.##.###",
        "###.##.##.########.##.##.###",
        "#......##....##....##......#",
        "#.##########.##.##########.#",
        "#.##########.##.##########.#",
        "#..........................#",
        "############################"
    },
    {
        "############################",
        "#.........#....#..........#",
        "#.#######.#.##.#.########.#",
        "#o#     #....#....#     #o#",
        "#.#.###.######.######.#.#.#",
        "#...#.............#...#...#",
        "#.###.##.########.##.###.##",
        "#.....##....##....##.....##",
        "#####.##### ## #####.#####",
        "     #.##### ## #####.#   ",
        "     #.##          ##.#   ",
        "     #.## ###--### ##.#   ",
        "######.## #GGGGGG# ##.#####",
        "T     .   #GGGGGG#   .    T",
        "######.## #GGGGGG# ##.#####",
        "     #.## ######## ##.#   ",
        "     #.##          ##.#   ",
        "     #.## ######## ##.#   ",
        "######.## ######## ##.#####",
        "#.........#....#..........#",
        "#.#######.#.##.#.########.#",
        "#o#     #....#....#     #o#",
        "#.#.###.######.######.#.#.#",
        "#...#.............#...#...#",
        "#.###.##.########.##.###.##",
        "#.....##....##....##.....##",
        "#.##########.##.##########.#",
        "#.##########.##.##########.#",
        "#..........................#",
        "#..........................#",
        "############################"
    }
};

/* ============================================================
 *  BST — O(log n) media
 * ============================================================ */

static BSTNode *bst_create_node(int score, const char *name) {
    BSTNode *n = (BSTNode *)malloc(sizeof(BSTNode));
    if (!n) { fprintf(stderr, "ERRO: malloc em bst_create_node\n"); exit(1); }
    n->score = score;
    strncpy(n->name, name, 15);
    n->name[15] = '\0';
    n->left = n->right = NULL;
    return n;
}

/* Insere score — O(log n) media */
BSTNode *bst_insert(BSTNode *root, int score, const char *name) {
    if (!root) return bst_create_node(score, name);
    if (score < root->score)
        root->left  = bst_insert(root->left,  score, name);
    else if (score > root->score)
        root->right = bst_insert(root->right, score, name);
    return root;
}

/* Busca score — O(log n) media */
BSTNode *bst_search(BSTNode *root, int score) {
    if (!root || root->score == score) return root;
    if (score < root->score) return bst_search(root->left,  score);
    return                          bst_search(root->right, score);
}

/* Menor no (mais a esquerda) — O(h) */
BSTNode *bst_min(BSTNode *root) {
    if (!root) return NULL;
    while (root->left) root = root->left;
    return root;
}

/* Maior no (mais a direita) — O(h) */
BSTNode *bst_max(BSTNode *root) {
    if (!root) return NULL;
    while (root->right) root = root->right;
    return root;
}

/* Remove tratando os 3 casos — O(log n) media */
BSTNode *bst_remove(BSTNode *root, int score) {
    if (!root) return NULL;
    if (score < root->score) {
        root->left  = bst_remove(root->left,  score);
    } else if (score > root->score) {
        root->right = bst_remove(root->right, score);
    } else {
        if (!root->left) { BSTNode *t = root->right; free(root); return t; }
        if (!root->right){ BSTNode *t = root->left;  free(root); return t; }
        BSTNode *succ = bst_min(root->right);
        root->score = succ->score;
        strncpy(root->name, succ->name, 15);
        root->right = bst_remove(root->right, succ->score);
    }
    return root;
}

/* Altura — O(n) */
int bst_height(BSTNode *root) {
    if (!root) return 0;
    int l = bst_height(root->left);
    int r = bst_height(root->right);
    return 1 + (l > r ? l : r);
}

/* Contagem de nos — O(n) */
int bst_count(BSTNode *root) {
    if (!root) return 0;
    return 1 + bst_count(root->left) + bst_count(root->right);
}

/* Inorder crescente — O(n) */
void bst_inorder(BSTNode *root, int *arr, int *count, int max) {
    if (!root || *count >= max) return;
    bst_inorder(root->left, arr, count, max);
    if (*count < max) arr[(*count)++] = root->score;
    bst_inorder(root->right, arr, count, max);
}

/* Inorder decrescente — O(n) */
void bst_inorder_rev(BSTNode *root, int *arr, char names[][16], int *count, int max) {
    if (!root || *count >= max) return;
    bst_inorder_rev(root->right, arr, names, count, max);
    if (*count < max) {
        arr[*count] = root->score;
        strncpy(names[*count], root->name, 15);
        names[*count][15] = '\0';
        (*count)++;
    }
    bst_inorder_rev(root->left, arr, names, count, max);
}

/* Libera memoria — O(n) */
void bst_free(BSTNode *root) {
    if (!root) return;
    bst_free(root->left);
    bst_free(root->right);
    free(root);
}

/* M02: ASCII art da BST — O(n) */
void bst_print_ascii(BSTNode *root, int level, int is_right) {
    if (!root) return;
    bst_print_ascii(root->right, level + 1, 1);
    for (int i = 0; i < level; i++) printf("       ");
    if (level > 0) printf(is_right ? " ┌─── " : " └─── ");
    printf("%s[%d]%s\n", CLR_CYAN, root->score, CLR_RESET);
    bst_print_ascii(root->left, level + 1, 0);
}

/* ============================================================
 *  AVL — O(log n) garantido
 * ============================================================ */

int avl_height(AVLNode *node) { return node ? node->height : 0; }

static int avl_max(int a, int b) { return a > b ? a : b; }

/* Fator de balanceamento — O(1) */
int avl_balance_factor(AVLNode *node) {
    if (!node) return 0;
    return avl_height(node->left) - avl_height(node->right);
}

static void avl_update_height(AVLNode *node) {
    if (node)
        node->height = 1 + avl_max(avl_height(node->left), avl_height(node->right));
}

/* Contadores globais de rotacoes */
static int g_avl_rot_simple = 0;
static int g_avl_rot_double = 0;

/* Rotacao simples direita — O(1) */
AVLNode *avl_rotate_right(AVLNode *y) {
    AVLNode *x  = y->left;
    AVLNode *T2 = x->right;
    x->right = y; y->left = T2;
    avl_update_height(y); avl_update_height(x);
    g_avl_rot_simple++;
    return x;
}

/* Rotacao simples esquerda — O(1) */
AVLNode *avl_rotate_left(AVLNode *x) {
    AVLNode *y  = x->right;
    AVLNode *T2 = y->left;
    y->left = x; x->right = T2;
    avl_update_height(x); avl_update_height(y);
    g_avl_rot_simple++;
    return y;
}

/* Rotacao dupla LR — O(1) */
AVLNode *avl_rotate_left_right(AVLNode *node) {
    g_avl_rot_simple -= 2;
    node->left = avl_rotate_left(node->left);
    AVLNode *r = avl_rotate_right(node);
    g_avl_rot_double++;
    return r;
}

/* Rotacao dupla RL — O(1) */
AVLNode *avl_rotate_right_left(AVLNode *node) {
    g_avl_rot_simple -= 2;
    node->right = avl_rotate_right(node->right);
    AVLNode *r = avl_rotate_left(node);
    g_avl_rot_double++;
    return r;
}

static AVLNode *avl_balance(AVLNode *node) {
    if (!node) return NULL;
    avl_update_height(node);
    int bf = avl_balance_factor(node);
    if (bf > 1) {
        if (avl_balance_factor(node->left) >= 0) return avl_rotate_right(node);
        else                                      return avl_rotate_left_right(node);
    }
    if (bf < -1) {
        if (avl_balance_factor(node->right) <= 0) return avl_rotate_left(node);
        else                                       return avl_rotate_right_left(node);
    }
    return node;
}

/* Insere na AVL — O(log n) */
AVLNode *avl_insert(AVLNode *root, int key, int value) {
    if (!root) {
        AVLNode *n = (AVLNode *)malloc(sizeof(AVLNode));
        if (!n) { fprintf(stderr, "ERRO: malloc em avl_insert\n"); exit(1); }
        n->key = key; n->value = value; n->height = 1;
        n->left = n->right = NULL;
        return n;
    }
    if (key < root->key)       root->left  = avl_insert(root->left,  key, value);
    else if (key > root->key)  root->right = avl_insert(root->right, key, value);
    else                       root->value += value;
    return avl_balance(root);
}

/* Busca na AVL — O(log n) */
AVLNode *avl_search(AVLNode *root, int key) {
    if (!root || root->key == key) return root;
    if (key < root->key) return avl_search(root->left,  key);
    return                       avl_search(root->right, key);
}

/* Remove da AVL — O(log n) */
AVLNode *avl_remove(AVLNode *root, int key) {
    if (!root) return NULL;
    if (key < root->key) {
        root->left  = avl_remove(root->left,  key);
    } else if (key > root->key) {
        root->right = avl_remove(root->right, key);
    } else {
        if (!root->left || !root->right) {
            AVLNode *t = root->left ? root->left : root->right;
            free(root); return t;
        }
        AVLNode *succ = root->right;
        while (succ->left) succ = succ->left;
        root->key = succ->key; root->value = succ->value;
        root->right = avl_remove(root->right, succ->key);
    }
    return avl_balance(root);
}

/* Libera AVL — O(n) */
void avl_free(AVLNode *root) {
    if (!root) return;
    avl_free(root->left);
    avl_free(root->right);
    free(root);
}
/* ============================================================
 *  GRAFO — Dupla representacao
 * ============================================================ */

int model_coord_to_vertex(int x, int y) { return y * MAP_W + x; }

void model_vertex_to_coord(int v, int *x, int *y) {
    *x = v % MAP_W; *y = v / MAP_W;
}

/* Cria grafo — O(V) */
Graph *graph_create(int num_vertices) {
    Graph *g = (Graph *)malloc(sizeof(Graph));
    if (!g) { fprintf(stderr, "ERRO: malloc em graph_create\n"); exit(1); }
    g->num_vertices = num_vertices;
    g->adj_list = (AdjNode **)calloc(num_vertices, sizeof(AdjNode *));
    if (!g->adj_list) { fprintf(stderr, "ERRO: calloc lista\n"); exit(1); }
    g->adj_matrix = (int *)calloc(num_vertices * num_vertices, sizeof(int));
    if (!g->adj_matrix) { fprintf(stderr, "ERRO: calloc matriz\n"); exit(1); }
    g->matrix_allocated = 1;
    return g;
}

/* Aresta bidirecional — O(1)
 * BUG3 CORRIGIDO: insere nos dois sentidos na lista */
void graph_add_edge(Graph *g, int u, int v, int weight) {
    AdjNode *uv = (AdjNode *)malloc(sizeof(AdjNode));
    if (!uv) { fprintf(stderr, "ERRO: malloc em graph_add_edge\n"); exit(1); }
    uv->vertex = v; uv->weight = weight;
    uv->next = g->adj_list[u]; g->adj_list[u] = uv;

    AdjNode *vu = (AdjNode *)malloc(sizeof(AdjNode));
    if (!vu) { fprintf(stderr, "ERRO: malloc em graph_add_edge\n"); exit(1); }
    vu->vertex = u; vu->weight = weight;
    vu->next = g->adj_list[v]; g->adj_list[v] = vu;

    g->adj_matrix[u * g->num_vertices + v] = weight;
    g->adj_matrix[v * g->num_vertices + u] = weight;
}

int graph_has_edge_matrix(Graph *g, int u, int v) {
    return g->adj_matrix[u * g->num_vertices + v] > 0;
}

int graph_has_edge_list(Graph *g, int u, int v) {
    AdjNode *c = g->adj_list[u];
    while (c) { if (c->vertex == v) return 1; c = c->next; }
    return 0;
}

/* Constroi grafo do mapa — O(V+E) */
void graph_build_from_map(Graph *g, int grid[MAP_H][MAP_W]) {
    int dirs[2][2] = {{1,0},{0,1}};
    for (int y = 0; y < MAP_H; y++) {
        for (int x = 0; x < MAP_W; x++) {
            if (grid[y][x] == TILE_WALL) continue;
            int u = model_coord_to_vertex(x, y);
            for (int d = 0; d < 2; d++) {
                int nx = x + dirs[d][0];
                int ny = y + dirs[d][1];
                if (nx >= MAP_W) nx = 0;
                if (ny < 0 || ny >= MAP_H) continue;
                if (grid[ny][nx] == TILE_WALL) continue;
                int v = model_coord_to_vertex(nx, ny);
                int w = (grid[ny][nx] == TILE_TUNNEL) ? 2 : 1;
                graph_add_edge(g, u, v, w);
            }
        }
    }
    if (grid[TUNNEL_ROW][0] != TILE_WALL && grid[TUNNEL_ROW][MAP_W-1] != TILE_WALL) {
        int u = model_coord_to_vertex(0, TUNNEL_ROW);
        int v = model_coord_to_vertex(MAP_W-1, TUNNEL_ROW);
        if (!graph_has_edge_list(g, u, v)) graph_add_edge(g, u, v, 2);
    }
}

/* Libera grafo — O(V+E) */
void graph_free(Graph *g) {
    if (!g) return;
    for (int i = 0; i < g->num_vertices; i++) {
        AdjNode *c = g->adj_list[i];
        while (c) { AdjNode *t = c; c = c->next; free(t); }
    }
    free(g->adj_list);
    if (g->matrix_allocated) free(g->adj_matrix);
    free(g);
}

/* ============================================================
 *  QUEUE
 * ============================================================ */

Queue *queue_create(void) {
    Queue *q = (Queue *)malloc(sizeof(Queue));
    if (!q) { fprintf(stderr, "ERRO: malloc em queue_create\n"); exit(1); }
    q->front = q->rear = NULL; q->size = 0;
    return q;
}

void queue_push(Queue *q, int data) {
    QueueNode *n = (QueueNode *)malloc(sizeof(QueueNode));
    if (!n) { fprintf(stderr, "ERRO: malloc em queue_push\n"); exit(1); }
    n->data = data; n->next = NULL;
    if (q->rear) q->rear->next = n; else q->front = n;
    q->rear = n; q->size++;
}

int queue_pop(Queue *q) {
    if (!q->front) return -1;
    QueueNode *t = q->front; int d = t->data;
    q->front = t->next;
    if (!q->front) q->rear = NULL;
    free(t); q->size--;
    return d;
}

int  queue_empty(Queue *q) { return q->size == 0; }
void queue_free(Queue *q)  { while (!queue_empty(q)) queue_pop(q); free(q); }

/* ============================================================
 *  MIN-HEAP
 * ============================================================ */

MinHeap *heap_create(int capacity) {
    MinHeap *h = (MinHeap *)malloc(sizeof(MinHeap));
    if (!h) { fprintf(stderr, "ERRO: malloc em heap_create\n"); exit(1); }
    h->items = (HeapItem *)malloc(sizeof(HeapItem) * capacity);
    if (!h->items) { fprintf(stderr, "ERRO: malloc items\n"); exit(1); }
    h->size = 0; h->capacity = capacity;
    return h;
}

static void heap_swap(HeapItem *a, HeapItem *b) { HeapItem t = *a; *a = *b; *b = t; }

void heap_push(MinHeap *h, int vertex, int dist) {
    if (h->size >= h->capacity) return;
    h->items[h->size] = (HeapItem){vertex, dist};
    int i = h->size++;
    while (i > 0) {
        int p = (i-1)/2;
        if (h->items[p].dist > h->items[i].dist) { heap_swap(&h->items[p], &h->items[i]); i = p; }
        else break;
    }
}

HeapItem heap_pop(MinHeap *h) {
    HeapItem top = h->items[0];
    h->items[0] = h->items[--h->size];
    int i = 0;
    while (1) {
        int s = i, l = 2*i+1, r = 2*i+2;
        if (l < h->size && h->items[l].dist < h->items[s].dist) s = l;
        if (r < h->size && h->items[r].dist < h->items[s].dist) s = r;
        if (s != i) { heap_swap(&h->items[i], &h->items[s]); i = s; }
        else break;
    }
    return top;
}

int  heap_empty(MinHeap *h) { return h->size == 0; }
void heap_free(MinHeap *h)  { free(h->items); free(h); }

/* ============================================================
 *  Contadores de nos visitados pelos algoritmos
 * ============================================================ */

static int s_bfs_count      = 0;
static int s_dfs_count      = 0;
static int s_dijkstra_count = 0;

int model_get_bfs_count(void)      { return s_bfs_count; }
int model_get_dfs_count(void)      { return s_dfs_count; }
int model_get_dijkstra_count(void) { return s_dijkstra_count; }

/* ============================================================
 *  BFS — O(V+E)
 * ============================================================ */

void bfs(Graph *g, int src, int *dist, int *prev) {
    int n = g->num_vertices;
    for (int i = 0; i < n; i++) { dist[i] = INF; prev[i] = -1; }
    dist[src] = 0;
    Queue *q = queue_create();
    queue_push(q, src);
    s_bfs_count = 0; /* reseta contador */
    while (!queue_empty(q)) {
        int u = queue_pop(q);
        s_bfs_count++; /* conta no visitado */
        for (AdjNode *a = g->adj_list[u]; a; a = a->next) {
            if (dist[a->vertex] == INF) {
                dist[a->vertex] = dist[u] + 1;
                prev[a->vertex] = u;
                queue_push(q, a->vertex);
            }
        }
    }
    queue_free(q);
}

/* ============================================================
 *  DFS — O(V+E)
 * ============================================================ */

static int dfs_found_flag;

static void dfs_helper(Graph *g, int cur, int dst,
                        int *visited, int *path, int *path_len) {
    if (dfs_found_flag) return;
    visited[cur] = 1;
    s_dfs_count++; /* conta no visitado */
    path[(*path_len)++] = cur;
    if (cur == dst) { dfs_found_flag = 1; return; }
    for (AdjNode *a = g->adj_list[cur]; a && !dfs_found_flag; a = a->next)
        if (!visited[a->vertex])
            dfs_helper(g, a->vertex, dst, visited, path, path_len);
    if (!dfs_found_flag) (*path_len)--;
}

void dfs(Graph *g, int src, int dst, int *visited, int *path, int *path_len) {
    int n = g->num_vertices;
    for (int i = 0; i < n; i++) visited[i] = 0;
    *path_len = 0; dfs_found_flag = 0;
    s_dfs_count = 0; /* reseta contador */
    dfs_helper(g, src, dst, visited, path, path_len);
}

/* ============================================================
 *  DIJKSTRA — O((V+E) log V)
 * ============================================================ */

void dijkstra(Graph *g, int src, int *dist, int *prev, int *visited_buf) {
    int n = g->num_vertices;
    for (int i = 0; i < n; i++) { dist[i] = INF; prev[i] = -1; visited_buf[i] = 0; }
    dist[src] = 0;
    s_dijkstra_count = 0; /* reseta contador */
    MinHeap *h = heap_create(n * 2);
    heap_push(h, src, 0);
    while (!heap_empty(h)) {
        HeapItem top = heap_pop(h);
        int u = top.vertex;
        if (visited_buf[u]) continue;
        visited_buf[u] = 1;
        s_dijkstra_count++; /* conta no visitado */
        for (AdjNode *a = g->adj_list[u]; a; a = a->next) {
            int v = a->vertex, w = a->weight;
            if (!visited_buf[v] && dist[u] + w < dist[v]) {
                dist[v] = dist[u] + w;
                prev[v] = u;
                heap_push(h, v, dist[v]);
            }
        }
    }
    heap_free(h);
}
/* ============================================================
 *  SORTS — todos decrescentes
 * ============================================================ */

/* Bubble — O(n²) medio, O(n) melhor */
void bubble_sort(int *arr, int n) {
    for (int i = 0; i < n-1; i++) {
        int sw = 0;
        for (int j = 0; j < n-i-1; j++)
            if (arr[j] < arr[j+1]) {
                int t = arr[j]; arr[j] = arr[j+1]; arr[j+1] = t; sw = 1;
            }
        if (!sw) break;
    }
}

/* Selection — O(n²) sempre */
void selection_sort(int *arr, int n) {
    for (int i = 0; i < n-1; i++) {
        int m = i;
        for (int j = i+1; j < n; j++) if (arr[j] > arr[m]) m = j;
        if (m != i) { int t = arr[i]; arr[i] = arr[m]; arr[m] = t; }
    }
}

/* Insertion — O(n²) medio, O(n) melhor */
void insertion_sort(int *arr, int n) {
    for (int i = 1; i < n; i++) {
        int key = arr[i], j = i-1;
        while (j >= 0 && arr[j] < key) { arr[j+1] = arr[j]; j--; }
        arr[j+1] = key;
    }
}

/* Shell — O(n log² n) medio */
void shell_sort(int *arr, int n) {
    for (int gap = n/2; gap > 0; gap /= 2)
        for (int i = gap; i < n; i++) {
            int tmp = arr[i], j;
            for (j = i; j >= gap && arr[j-gap] < tmp; j -= gap) arr[j] = arr[j-gap];
            arr[j] = tmp;
        }
}

/* Merge — O(n log n) sempre */
static void merge(int *arr, int l, int m, int r) {
    int n1 = m-l+1, n2 = r-m;
    int *L = malloc(n1*sizeof(int)), *R = malloc(n2*sizeof(int));
    if (!L || !R) { fprintf(stderr, "ERRO: malloc em merge\n"); exit(1); }
    for (int i = 0; i < n1; i++) L[i] = arr[l+i];
    for (int i = 0; i < n2; i++) R[i] = arr[m+1+i];
    int i = 0, j = 0, k = l;
    while (i < n1 && j < n2) arr[k++] = (L[i] >= R[j]) ? L[i++] : R[j++];
    while (i < n1) arr[k++] = L[i++];
    while (j < n2) arr[k++] = R[j++];
    free(L); free(R);
}

static void merge_sort_helper(int *arr, int l, int r) {
    if (l < r) {
        int m = l + (r-l)/2;
        merge_sort_helper(arr, l, m);
        merge_sort_helper(arr, m+1, r);
        merge(arr, l, m, r);
    }
}

void merge_sort(int *arr, int n) { if (n > 1) merge_sort_helper(arr, 0, n-1); }

/* Quick — O(n log n) medio */
static int qs_partition(int *arr, int low, int high) {
    int pivot = arr[high], i = low-1;
    for (int j = low; j < high; j++)
        if (arr[j] >= pivot) { i++; int t = arr[i]; arr[i] = arr[j]; arr[j] = t; }
    int t = arr[i+1]; arr[i+1] = arr[high]; arr[high] = t;
    return i+1;
}

void quick_sort(int *arr, int low, int high) {
    if (low < high) {
        int pi = qs_partition(arr, low, high);
        quick_sort(arr, low, pi-1);
        quick_sort(arr, pi+1, high);
    }
}

/* Heap — O(n log n) sempre
 * BUG2 CORRIGIDO: era < em vez de > */
static void heapify_max(int *arr, int n, int i) {
    int largest = i, l = 2*i+1, r = 2*i+2;
    if (l < n && arr[l] > arr[largest]) largest = l;
    if (r < n && arr[r] > arr[largest]) largest = r;
    if (largest != i) {
        int t = arr[i]; arr[i] = arr[largest]; arr[largest] = t;
        heapify_max(arr, n, largest);
    }
}

void heap_sort(int *arr, int n) {
    for (int i = n/2-1; i >= 0; i--) heapify_max(arr, n, i);
    for (int i = n-1; i > 0; i--) {
        int t = arr[0]; arr[0] = arr[i]; arr[i] = t;
        heapify_max(arr, i, 0);
    }
}

/* M01 — mede tempo dos 7 sorts em microsegundos */
void model_run_all_sorts(GameModel *m) {
    if (m->score_history_count < 2) return;
    int n = m->score_history_count, tmp[MAX_SCORES];
    clock_t t0;

    memcpy(tmp, m->score_history, n*sizeof(int));
    t0 = clock(); bubble_sort(tmp, n);
    m->sort_times[0] = (long long)(clock()-t0)*1000000/CLOCKS_PER_SEC;

    memcpy(tmp, m->score_history, n*sizeof(int));
    t0 = clock(); selection_sort(tmp, n);
    m->sort_times[1] = (long long)(clock()-t0)*1000000/CLOCKS_PER_SEC;

    memcpy(tmp, m->score_history, n*sizeof(int));
    t0 = clock(); insertion_sort(tmp, n);
    m->sort_times[2] = (long long)(clock()-t0)*1000000/CLOCKS_PER_SEC;

    memcpy(tmp, m->score_history, n*sizeof(int));
    t0 = clock(); shell_sort(tmp, n);
    m->sort_times[3] = (long long)(clock()-t0)*1000000/CLOCKS_PER_SEC;

    memcpy(tmp, m->score_history, n*sizeof(int));
    t0 = clock(); merge_sort(tmp, n);
    m->sort_times[4] = (long long)(clock()-t0)*1000000/CLOCKS_PER_SEC;

    memcpy(tmp, m->score_history, n*sizeof(int));
    t0 = clock(); quick_sort(tmp, 0, n-1);
    m->sort_times[5] = (long long)(clock()-t0)*1000000/CLOCKS_PER_SEC;

    memcpy(tmp, m->score_history, n*sizeof(int));
    t0 = clock(); heap_sort(tmp, n);
    m->sort_times[6] = (long long)(clock()-t0)*1000000/CLOCKS_PER_SEC;
}

/* ============================================================
 *  P01 — Persistencia
 * ============================================================ */

#define SCORES_FILE "scores.dat"

static void bst_save_helper(BSTNode *root, FILE *f) {
    if (!root) return;
    fwrite(&root->score, sizeof(int),  1, f);
    fwrite(root->name,   sizeof(char), 16, f);
    bst_save_helper(root->left,  f);
    bst_save_helper(root->right, f);
}

void model_save_scores(GameModel *m) {
    FILE *f = fopen(SCORES_FILE, "wb");
    if (!f) return;
    int count = bst_count(m->score_tree);
    fwrite(&count, sizeof(int), 1, f);
    bst_save_helper(m->score_tree, f);
    fclose(f);
}

void model_load_scores(GameModel *m) {
    FILE *f = fopen(SCORES_FILE, "rb");
    if (!f) return;
    int count = 0;
    if (fread(&count, sizeof(int), 1, f) != 1) { fclose(f); return; }
    for (int i = 0; i < count; i++) {
        int score = 0; char name[16];
        if (fread(&score, sizeof(int),  1, f) != 1) break;
        if (fread(name,   sizeof(char), 16, f) != 16) break;
        m->score_tree = bst_insert(m->score_tree, score, name);
    }
    fclose(f);
}

/* ============================================================
 *  MODEL CORE
 * ============================================================ */

const char *model_map_name(int index) {
    static const char *names[MAP_COUNT] = {
        "Classico","Aberto","Corredor","Labirinto"
    };
    if (index < 0 || index >= MAP_COUNT) return "?";
    return names[index];
}

void model_init(GameModel *m) {
    memset(m, 0, sizeof(GameModel));
    m->lives = START_LIVES; m->level = 1;
    m->state = STATE_MENU;  m->running = 1;
    strncpy(m->player_name, "---", 15);
    g_avl_rot_simple = g_avl_rot_double = 0;

    m->score_tree = bst_insert(m->score_tree, 10000, "ACE");
    m->score_tree = bst_insert(m->score_tree,  8000, "BOB");
    m->score_tree = bst_insert(m->score_tree,  6000, "CAT");
    m->score_tree = bst_insert(m->score_tree,  4000, "DAN");
    m->score_tree = bst_insert(m->score_tree,  2000, "EVE");
    model_load_scores(m);

    m->powerup_tree = avl_insert(m->powerup_tree, 1, 0);
    m->powerup_tree = avl_insert(m->powerup_tree, 2, 0);
    m->powerup_tree = avl_insert(m->powerup_tree, 3, 0);
    m->powerup_tree = avl_insert(m->powerup_tree, 4, 0);
}

void model_load_map(GameModel *m) {
    m->pellets_left = m->total_pellets = 0;
    int idx = m->map_selected % MAP_COUNT;

    for (int y = 0; y < MAP_H; y++) {
        for (int x = 0; x < MAP_W; x++) {
            char c = (x < (int)strlen(maps[idx][y])) ? maps[idx][y][x] : ' ';
            switch (c) {
                case '#': m->grid[y][x] = TILE_WALL;   break;
                case '.': m->grid[y][x] = TILE_PELLET; m->pellets_left++; m->total_pellets++; break;
                case 'o': m->grid[y][x] = TILE_POWER;  m->pellets_left++; m->total_pellets++; break;
                case '-': m->grid[y][x] = TILE_DOOR;   break;
                case 'T': m->grid[y][x] = TILE_TUNNEL; break;
                default:  m->grid[y][x] = TILE_EMPTY;  break;
            }
        }
    }

    m->pacman = (Entity){14, 23, 0, 0, 14, 23};

    m->ghosts[0].e = (Entity){14,11,-1,0,14,11}; m->ghosts[0].symbol='B';
    m->ghosts[0].in_house=0; m->ghosts[0].release_timer=0;

    m->ghosts[1].e = (Entity){13,14,0,-1,13,14}; m->ghosts[1].symbol='P';
    m->ghosts[1].in_house=1; m->ghosts[1].release_timer=30;

    m->ghosts[2].e = (Entity){14,14,0,-1,14,14}; m->ghosts[2].symbol='I';
    m->ghosts[2].in_house=1; m->ghosts[2].release_timer=60;

    m->ghosts[3].e = (Entity){15,14,0,-1,15,14}; m->ghosts[3].symbol='C';
    m->ghosts[3].in_house=1; m->ghosts[3].release_timer=90;

    for (int i = 0; i < GHOSTS; i++) {
        m->ghosts[i].vulnerable = 0; m->ghosts[i].eaten = 0;
    }

    m->desired_dx = m->desired_dy = m->current_dx = m->current_dy = 0;
    m->power_timer = m->ghost_eat_combo = m->frame_count = 0;
    m->ready_timer = 25;

    /* Fruta bonus: reseta para este nivel */
    m->fruit_active = 0;
    m->fruit_timer  = 0; /* 0 = ainda nao apareceu */

    /* Velocidade dos fantasmas por nivel */
    m->ghost_speed_mod = (m->level <= 1) ? 2 : 1;

    /* Salva vidas para conquista pellet master */
    m->ach_lives_intact = m->lives;

    if (m->maze_graph) graph_free(m->maze_graph);
    m->maze_graph = graph_create(MAP_W * MAP_H);
    graph_build_from_map(m->maze_graph, m->grid);
}

int model_is_walkable(GameModel *m, int x, int y, int for_ghost) {
    if (x < 0 || x >= MAP_W) return (y == TUNNEL_ROW) ? 1 : 0;
    if (y < 0 || y >= MAP_H) return 0;
    if (m->grid[y][x] == TILE_WALL) return 0;
    if (!for_ghost && m->grid[y][x] == TILE_DOOR) return 0;
    return 1;
}

static void wrap_entity(Entity *e) {
    if (e->x < 0)      e->x = MAP_W-1;
    if (e->x >= MAP_W) e->x = 0;
}

void model_reset_positions(GameModel *m) {
    m->pacman.x = m->pacman.start_x; m->pacman.y = m->pacman.start_y;
    m->current_dx = m->current_dy = m->desired_dx = m->desired_dy = 0;
    m->ghosts[0].e = (Entity){14,11,-1,0,14,11};
    m->ghosts[1].e = (Entity){13,14,0,-1,13,14};
    m->ghosts[2].e = (Entity){14,14,0,-1,14,14};
    m->ghosts[3].e = (Entity){15,14,0,-1,15,14};
    for (int i = 0; i < GHOSTS; i++) {
        m->ghosts[i].vulnerable = 0; m->ghosts[i].eaten = 0;
        m->ghosts[i].in_house = (i > 0);
        m->ghosts[i].release_timer = i * 30;
    }
    m->ghosts[0].in_house = 0; m->ghosts[0].release_timer = 0;
    m->power_timer = m->ghost_eat_combo = 0; m->ready_timer = 25;
}
void model_move_pacman(GameModel *m) {
    if (model_is_walkable(m, m->pacman.x + m->desired_dx,
                             m->pacman.y + m->desired_dy, 0)) {
        m->current_dx = m->desired_dx; m->current_dy = m->desired_dy;
    }
    if (model_is_walkable(m, m->pacman.x + m->current_dx,
                             m->pacman.y + m->current_dy, 0)) {
        m->pacman.x += m->current_dx; m->pacman.y += m->current_dy;
        wrap_entity(&m->pacman);
    }
    if (m->grid[m->pacman.y][m->pacman.x] == TILE_PELLET) {
        m->grid[m->pacman.y][m->pacman.x] = TILE_EMPTY;
        m->score += 10; m->pellets_left--;
        if (m->score_history_count < MAX_SCORES)
            m->score_history[m->score_history_count++] = m->score;
    } else if (m->grid[m->pacman.y][m->pacman.x] == TILE_POWER) {
        m->grid[m->pacman.y][m->pacman.x] = TILE_EMPTY;
        m->score += 50; m->pellets_left--;
        m->power_timer = POWER_TIME; m->ghost_eat_combo = 0;
        for (int i = 0; i < GHOSTS; i++)
            if (!m->ghosts[i].eaten) m->ghosts[i].vulnerable = 1;
        int pu = (rand() % 4) + 1;
        m->powerup_tree = avl_insert(m->powerup_tree, pu, 1);
        m->avl_rotations_simple = g_avl_rot_simple;
        m->avl_rotations_double = g_avl_rot_double;
    }
    if (m->score > m->high_score) m->high_score = m->score;
}

/* Fruta bonus — aparece ao coletar 70% dos pellets */
void model_update_fruit(GameModel *m) {
    if (m->fruit_active) {
        /* Pac-Man coletou a fruta */
        if (m->pacman.x == m->fruit_x && m->pacman.y == m->fruit_y) {
            m->score       += 100;
            m->fruit_active = 0;
            m->bonus_points = 100;
            m->bonus_x      = m->fruit_x;
            m->bonus_y      = m->fruit_y;
            m->bonus_timer  = 15;
            if (m->score > m->high_score) m->high_score = m->score;
            return;
        }
        m->fruit_timer--;
        if (m->fruit_timer <= 0) m->fruit_active = 0;
        return;
    }
    /* Spawna quando 70% coletados e fruta ainda nao apareceu este nivel */
    if (m->fruit_timer == -1) return;
    int coletados = m->total_pellets - m->pellets_left;
    int limite    = m->total_pellets * 70 / 100;
    if (coletados < limite) return;

    /* Escolhe posicao vazia aleatoria */
    int tentativas = 0;
    while (tentativas++ < 100) {
        int fx = rand() % MAP_W;
        int fy = rand() % MAP_H;
        if (m->grid[fy][fx] == TILE_EMPTY &&
            !(fx == m->pacman.x && fy == m->pacman.y)) {
            m->fruit_x      = fx;
            m->fruit_y      = fy;
            m->fruit_active = 1;
            m->fruit_timer  = 150;
            break;
        }
    }
    /* Marca que ja apareceu (mesmo se nao achou posicao) */
    if (!m->fruit_active) m->fruit_timer = -1;
    else                  m->fruit_timer = 150;
    /* Seta -1 para nao tentar de novo */
    m->fruit_timer = m->fruit_active ? 150 : -1;
}

/* Conquistas */
void model_check_achievements(GameModel *m) {
    if (!m->ach_score_5000 && m->score >= 5000)
        m->ach_score_5000 = 1;
    if (!m->ach_ate_4_ghosts && m->ghost_eat_combo >= 4)
        m->ach_ate_4_ghosts = 1;
}

void model_move_ghosts(GameModel *m) {
    int dirs[4][2] = {{0,-1},{-1,0},{0,1},{1,0}};
    for (int i = 0; i < GHOSTS; i++) {
        Ghost *g = &m->ghosts[i];
        if (g->in_house) {
            if (g->release_timer > 0) { g->release_timer--; continue; }
            g->e.x = 14; g->e.y = 11;
            g->e.dx = (rand()%2) ? 1 : -1; g->e.dy = 0;
            g->in_house = 0; continue;
        }
        if (g->vulnerable && m->frame_count % 2 != 0) continue;

        int tx = m->pacman.x, ty = m->pacman.y;
        int src = model_coord_to_vertex(g->e.x, g->e.y);
        int dst = model_coord_to_vertex(tx, ty);
        int next_v = -1;

        if (i == 0 && !g->vulnerable) {
            dijkstra(m->maze_graph, src,
                     m->dijkstra_dist, m->dijkstra_prev, m->search_visited);
            int cur = dst;
            while (cur != -1 && m->dijkstra_prev[cur] != src &&
                   m->dijkstra_prev[cur] != -1)
                cur = m->dijkstra_prev[cur];
            if (cur != -1 && m->dijkstra_prev[cur] == src) next_v = cur;
        } else if (i == 1 && !g->vulnerable) {
            bfs(m->maze_graph, src, m->bfs_dist, m->bfs_prev);
            int cur = dst;
            while (cur != -1 && m->bfs_prev[cur] != src &&
                   m->bfs_prev[cur] != -1)
                cur = m->bfs_prev[cur];
            if (cur != -1 && m->bfs_prev[cur] == src) next_v = cur;
        } else if (i == 2 && !g->vulnerable) {
            dfs(m->maze_graph, src, dst,
                m->search_visited, m->dfs_path, &m->dfs_path_len);
            if (m->dfs_path_len >= 2) next_v = m->dfs_path[1];
        }

        if (next_v >= 0) {
            int nx, ny;
            model_vertex_to_coord(next_v, &nx, &ny);
            g->e.dx = nx - g->e.x;
            g->e.dy = ny - g->e.y;
            if (g->e.dx >  1) g->e.dx = -1;
            if (g->e.dx < -1) g->e.dx =  1;
        } else {
            int best = g->vulnerable ? -1 : INF;
            int bdx = g->e.dx, bdy = g->e.dy;
            for (int d = 0; d < 4; d++) {
                int dx = dirs[d][0], dy = dirs[d][1];
                if (dx == -g->e.dx && dy == -g->e.dy) continue;
                int nx = g->e.x + dx, ny = g->e.y + dy;
                if (!model_is_walkable(m, nx, ny, 1)) continue;
                int dist = manhattan((nx+MAP_W)%MAP_W, ny, tx, ty);
                if (!g->vulnerable && dist < best)  { best=dist; bdx=dx; bdy=dy; }
                else if (g->vulnerable && dist > best) { best=dist; bdx=dx; bdy=dy; }
            }
            g->e.dx = bdx; g->e.dy = bdy;
        }

        if (model_is_walkable(m, g->e.x+g->e.dx, g->e.y+g->e.dy, 1)) {
            g->e.x += g->e.dx; g->e.y += g->e.dy;
            wrap_entity(&g->e);
        }
    }
}

int model_check_collisions(GameModel *m) {
    for (int i = 0; i < GHOSTS; i++) {
        if (m->ghosts[i].e.x == m->pacman.x &&
            m->ghosts[i].e.y == m->pacman.y) {
            if (m->ghosts[i].vulnerable) {
                m->ghost_eat_combo++;
                int bonus = 200 * m->ghost_eat_combo;
                m->score += bonus;
                if (m->score > m->high_score) m->high_score = m->score;
                m->ghosts[i].e.x = m->ghosts[i].e.start_x;
                m->ghosts[i].e.y = m->ghosts[i].e.start_y;
                m->ghosts[i].vulnerable = 0; m->ghosts[i].eaten = 1;
                m->ghosts[i].in_house = 1;   m->ghosts[i].release_timer = 15;
                return bonus;
            } else {
                m->lives--;
                if (m->lives <= 0) {
                    m->state = STATE_GAMEOVER;
                    m->score_tree = bst_insert(m->score_tree,
                                               m->score, m->player_name);
                    if (bst_count(m->score_tree) > 10) {
                        BSTNode *mn = bst_min(m->score_tree);
                        if (mn) m->score_tree = bst_remove(m->score_tree,
                                                            mn->score);
                    }
                    model_save_scores(m);
                    m->avl_rotations_simple = g_avl_rot_simple;
                    m->avl_rotations_double = g_avl_rot_double;
                } else {
                    m->state = STATE_DYING; m->death_anim = 0;
                }
                return -1;
            }
        }
    }
    return 0;
}

/* P06 — Relatorio final */
void model_print_final_report(GameModel *m) {
    const char *snames[7] = {
        "Bubble","Selection","Insertion","Shell","Merge","Quick","Heap"
    };
    printf("\n%s╔══════════════════════════════════════════╗%s\n", CLR_WALL, CLR_RESET);
    printf("%s║%s   RELATORIO FINAL                         %s║%s\n", CLR_WALL, CLR_TITLE, CLR_WALL, CLR_RESET);
    printf("%s╠══════════════════════════════════════════╣%s\n", CLR_WALL, CLR_RESET);
    printf("%s║%s  Score: %s%-8d%s  High: %s%-8d%s        %s║%s\n",
           CLR_WALL, CLR_RESET, CLR_SCORE, m->score, CLR_RESET,
           CLR_CYAN,  m->high_score, CLR_RESET, CLR_WALL, CLR_RESET);
    printf("%s║%s  Nivel: %s%-3d%s                               %s║%s\n",
           CLR_WALL, CLR_RESET, CLR_GREEN, m->level, CLR_RESET, CLR_WALL, CLR_RESET);
    printf("%s╠══════════════════════════════════════════╣%s\n", CLR_WALL, CLR_RESET);
    printf("%s║%s  BST altura: %s%d%s  nos: %s%d%s                  %s║%s\n",
           CLR_WALL, CLR_RESET,
           CLR_CYAN, bst_height(m->score_tree), CLR_RESET,
           CLR_CYAN, bst_count(m->score_tree),  CLR_RESET,
           CLR_WALL, CLR_RESET);
    printf("%s║%s  AVL rot.S: %s%d%s  rot.D: %s%d%s               %s║%s\n",
           CLR_WALL, CLR_RESET,
           CLR_GREEN,  m->avl_rotations_simple, CLR_RESET,
           CLR_ORANGE, m->avl_rotations_double, CLR_RESET,
           CLR_WALL, CLR_RESET);
    printf("%s╠══════════════════════════════════════════╣%s\n", CLR_WALL, CLR_RESET);
    if (m->score_history_count >= 2) {
        int best = 0;
        for (int i = 1; i < 7; i++)
            if (m->sort_times[i] > 0 && m->sort_times[i] < m->sort_times[best])
                best = i;
        printf("%s║%s  Sort mais rapido: %s%-10s%s             %s║%s\n",
               CLR_WALL, CLR_RESET, CLR_TITLE, snames[best], CLR_RESET,
               CLR_WALL, CLR_RESET);
        for (int i = 0; i < 7; i++)
            printf("%s║%s  %-10s : %s%4lld us%s                      %s║%s\n",
                   CLR_WALL, CLR_RESET, snames[i],
                   CLR_DIM, m->sort_times[i], CLR_RESET,
                   CLR_WALL, CLR_RESET);
    }
    printf("%s╠══════════════════════════════════════════╣%s\n", CLR_WALL, CLR_RESET);
    printf("%s║%s  CONQUISTAS                               %s║%s\n",
           CLR_WALL, CLR_TITLE, CLR_WALL, CLR_RESET);
    printf("%s║%s  %s%s%s Primeira Vitoria                    %s║%s\n",
           CLR_WALL, CLR_RESET,
           m->ach_first_win     ? CLR_GREEN : CLR_DIM,
           m->ach_first_win     ? "★" : "☆", CLR_RESET,
           CLR_WALL, CLR_RESET);
    printf("%s║%s  %s%s%s 5000 Pontos                         %s║%s\n",
           CLR_WALL, CLR_RESET,
           m->ach_score_5000    ? CLR_GREEN : CLR_DIM,
           m->ach_score_5000    ? "★" : "☆", CLR_RESET,
           CLR_WALL, CLR_RESET);
    printf("%s║%s  %s%s%s Comeu 4 Fantasmas                   %s║%s\n",
           CLR_WALL, CLR_RESET,
           m->ach_ate_4_ghosts  ? CLR_GREEN : CLR_DIM,
           m->ach_ate_4_ghosts  ? "★" : "☆", CLR_RESET,
           CLR_WALL, CLR_RESET);
    printf("%s║%s  %s%s%s Mestre dos Pellets                  %s║%s\n",
           CLR_WALL, CLR_RESET,
           m->ach_pellet_master ? CLR_GREEN : CLR_DIM,
           m->ach_pellet_master ? "★" : "☆", CLR_RESET,
           CLR_WALL, CLR_RESET);
    printf("%s╚══════════════════════════════════════════╝%s\n\n", CLR_WALL, CLR_RESET);
}

void model_free(GameModel *m) {
    bst_free(m->score_tree);
    avl_free(m->powerup_tree);
    if (m->maze_graph) graph_free(m->maze_graph);
    m->score_tree = NULL; m->powerup_tree = NULL; m->maze_graph = NULL;
}