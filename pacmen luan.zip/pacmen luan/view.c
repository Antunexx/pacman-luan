/*
 * ============================================================
 *  VIEW — Renderizacao no terminal
 * ============================================================
 *  BUG1 corrigido: kbhit_custom usava getchar() bloqueante
 *
 *  Features implementadas:
 *  - Debug expandido (posicoes, BST, AVL)
 *  - Fruta bonus
 *  - Animacao do Pac-Man com 4 frames por direcao
 *  - Barra de progresso dos pellets
 *  - Estatisticas BFS/DFS/Dijkstra no painel
 *  - Sistema de conquistas
 *  - Tela de pausa (M07)
 *  - Tela de ajuda (M08)
 *  - Banner de nivel
 * ============================================================
 */
#ifndef _WIN32
#define _POSIX_C_SOURCE 199309L
#endif
#include "pacman.h"

#ifdef _WIN32
static HANDLE hConsole;
static DWORD  dwOriginalMode;
#else
static struct termios orig_termios;
#endif

static int debug_mode = 0;

static int frame_cache_initialized = 0;
static int prev_pac_x = 0, prev_pac_y = 0;
static int prev_ghost_x[GHOSTS], prev_ghost_y[GHOSTS], prev_ghost_visible[GHOSTS];
static int prev_fruit_active = 0, prev_fruit_x = 0, prev_fruit_y = 0;
static int prev_bonus_active = 0, prev_bonus_x = 0, prev_bonus_y = 0;

/* ============================================================
 *  UTILIDADES
 * ============================================================ */

static void move_cursor(int row, int col) {
    printf("\033[%d;%dH", row, col);
}

static void hide_cursor(void) { printf("\033[?25l"); }
static void show_cursor(void) { printf("\033[?25h"); }

void view_clear(void)  { printf("\033[2J\033[H"); }
void view_flush(void)  { fflush(stdout); }
void view_set_debug(int on) { debug_mode = on; }
int  view_get_debug(void)   { return debug_mode; }
void view_reset_frame_cache(void) { frame_cache_initialized = 0; }

void enable_ansi(void) {
#ifdef _WIN32
    hConsole = GetStdHandle(STD_OUTPUT_HANDLE);
    GetConsoleMode(hConsole, &dwOriginalMode);
    SetConsoleMode(hConsole, dwOriginalMode | ENABLE_VIRTUAL_TERMINAL_PROCESSING);
#endif
}

void sleep_ms(int ms) {
#ifdef _WIN32
    Sleep(ms);
#else
    struct timespec ts;
    ts.tv_sec = ms / 1000;
    ts.tv_nsec = (long)(ms % 1000) * 1000000L;
    nanosleep(&ts, NULL);
#endif
}

int manhattan(int x1, int y1, int x2, int y2) {
    int dx = x1-x2; if (dx<0) dx=-dx;
    int dy = y1-y2; if (dy<0) dy=-dy;
    return dx+dy;
}

/* BUG1 CORRIGIDO: era getchar() bloqueante */
int kbhit_custom(void) {
#ifdef _WIN32
    return _kbhit();
#else
    char c;
    int r = read(STDIN_FILENO, &c, 1);
    if (r > 0) { ungetc(c, stdin); return 1; }
    return 0;
#endif
}

int getch_custom(void) {
#ifdef _WIN32
    return _getch();
#else
    return getchar();
#endif
}

/* ============================================================
 *  INICIALIZACAO E LIMPEZA
 * ============================================================ */

void view_init(void) {
    enable_ansi();
#ifndef _WIN32
    tcgetattr(STDIN_FILENO, &orig_termios);
    struct termios raw = orig_termios;
    raw.c_lflag &= ~(ECHO | ICANON);
    raw.c_cc[VMIN]  = 0;
    raw.c_cc[VTIME] = 0;
    tcsetattr(STDIN_FILENO, TCSANOW, &raw);
    int flags = fcntl(STDIN_FILENO, F_GETFL, 0);
    fcntl(STDIN_FILENO, F_SETFL, flags | O_NONBLOCK);
#endif
    hide_cursor();
    view_clear();
}

void view_cleanup(void) {
#ifndef _WIN32
    tcsetattr(STDIN_FILENO, TCSANOW, &orig_termios);
    int flags = fcntl(STDIN_FILENO, F_GETFL, 0);
    fcntl(STDIN_FILENO, F_SETFL, flags & ~O_NONBLOCK);
#endif
    show_cursor();
    printf(CLR_RESET "\n");
}

/* ============================================================
 *  SPLASH
 * ============================================================ */

void view_draw_splash(GameModel *m) {
    view_clear();
    int row = 4;
    move_cursor(row++, 8);
    printf("%s ____   _    ____      __  __    _    _   _ %s", CLR_TITLE, CLR_RESET);
    move_cursor(row++, 8);
    printf("%s|  _ \\ / \\  / ___|    |  \\/  |  / \\  | \\ | |%s", CLR_TITLE, CLR_RESET);
    move_cursor(row++, 8);
    printf("%s| |_) / _ \\| |   _____| |\\/| | / _ \\ |  \\| |%s", CLR_TITLE_ALT, CLR_RESET);
    move_cursor(row++, 8);
    printf("%s|  __/ ___ \\ |__|_____| |  | |/ ___ \\| |\\  |%s", CLR_TITLE_ALT, CLR_RESET);
    move_cursor(row++, 8);
    printf("%s|_| /_/   \\_\\____|    |_|  |_/_/   \\_\\_| \\_|%s", CLR_TITLE, CLR_RESET);
    row += 2;
    move_cursor(row++, 12);
    printf("%sEstrutura de Dados Aplicadas%s", CLR_SUBTITLE, CLR_RESET);
    move_cursor(row++, 14);
    printf("%sAnalise e Desenvolvimento de Sistemas%s", CLR_DIM, CLR_RESET);
    row += 2;
    move_cursor(row++, 16);
    printf("%sBST  AVL  Grafos  7 Sorts  MVC%s", CLR_CYAN, CLR_RESET);
    row += 3;
    move_cursor(row, 18);
    printf("%s[ Pressione qualquer tecla ]%s", CLR_READY, CLR_RESET);
    view_flush();
    sleep_ms(300);
    while (!kbhit_custom()) sleep_ms(50);
    getch_custom();
    m->splash_shown = 1;
}

/* ============================================================
 *  MENU PRINCIPAL
 * ============================================================ */

void view_draw_menu(GameModel *m) {
    view_clear();
    int row = 3;

    move_cursor(row++, 6);
    printf("%s ██████╗  █████╗  ██████╗    ███╗   ███╗ █████╗ ███╗  ██╗%s", CLR_TITLE, CLR_RESET);
    move_cursor(row++, 6);
    printf("%s██╔══██╗██╔══██╗██╔════╝    ████╗ ████║██╔══██╗████╗ ██║%s", CLR_TITLE_ALT, CLR_RESET);
    move_cursor(row++, 6);
    printf("%s██████╔╝███████║██║         ██╔████╔██║███████║██╔██╗██║%s", CLR_TITLE, CLR_RESET);
    move_cursor(row++, 6);
    printf("%s██╔═══╝ ██╔══██║██║         ██║╚██╔╝██║██╔══██║██║╚████║%s", CLR_TITLE_ALT, CLR_RESET);
    move_cursor(row++, 6);
    printf("%s██║     ██║  ██║╚██████╗    ██║ ╚═╝ ██║██║  ██║██║ ╚███║%s", CLR_TITLE, CLR_RESET);
    move_cursor(row++, 6);
    printf("%s╚═╝     ╚═╝  ╚═╝ ╚═════╝    ╚═╝     ╚═╝╚═╝  ╚═╝╚═╝  ╚══╝%s", CLR_DIM, CLR_RESET);

    row += 2;
    const char *opcoes[] = {"  JOGAR", "  HIGH SCORES", "  AJUDA", "  SAIR"};
    for (int i = 0; i < 4; i++) {
        move_cursor(row + i*2, 14);
        if (i == m->menu_selected)
            printf("%s%s► %s%s%s", CLR_SEL_BG, CLR_TITLE, opcoes[i], CLR_RESET, CLR_RESET);
        else
            printf("%s  %s%s", CLR_DIM, opcoes[i], CLR_RESET);
    }

    row += 10;
    move_cursor(row++, 10);
    printf("%sMapa: %s[ ← ] %s%-10s%s [ → ]%s",
           CLR_DIM, CLR_CYAN, CLR_SUBTITLE,
           model_map_name(m->map_selected), CLR_CYAN, CLR_RESET);
    row++;
    move_cursor(row++, 10);
    printf("%s↑↓ Navegar   Enter Confirmar   Q Sair%s", CLR_DIM, CLR_RESET);
    move_cursor(row, 10);
    printf("%sHigh Score: %s%d%s", CLR_DIM, CLR_SCORE, m->high_score, CLR_RESET);
    view_flush();
}

/* ============================================================
 *  SCORES (Ranking + BST ASCII + Sorts M01/M02)
 * ============================================================ */

void view_draw_scores(GameModel *m) {
    view_clear();
    int row = 2;

    move_cursor(row++, 10);
    printf("%s╔══════════════════════════════════════╗%s", CLR_WALL, CLR_RESET);
    move_cursor(row++, 10);
    printf("%s║%s      HIGH SCORES — BST RANKING        %s║%s",
           CLR_WALL, CLR_TITLE, CLR_WALL, CLR_RESET);
    move_cursor(row++, 10);
    printf("%s╠══════════════════════════════════════╣%s", CLR_WALL, CLR_RESET);

    int scores[MAX_SCORES]; char names[MAX_SCORES][16]; int count = 0;
    bst_inorder_rev(m->score_tree, scores, names, &count, 10);

    for (int i = 0; i < count; i++) {
        move_cursor(row++, 10);
        printf("%s║%s  %s%2d.%s %-15s %s%6d%s pts  %s║%s",
               CLR_WALL, CLR_RESET,
               i == 0 ? CLR_TITLE : CLR_DIM, i+1, CLR_RESET,
               names[i],
               i == 0 ? CLR_SCORE : CLR_CYAN, scores[i], CLR_RESET,
               CLR_WALL, CLR_RESET);
    }

    move_cursor(row++, 10);
    printf("%s╠══════════════════════════════════════╣%s", CLR_WALL, CLR_RESET);
    move_cursor(row++, 10);
    printf("%s║%s  BST altura:%s%d%s nos:%s%d%s min:%s%d%s max:%s%d%s %s║%s",
           CLR_WALL, CLR_RESET,
           CLR_CYAN, bst_height(m->score_tree), CLR_RESET,
           CLR_CYAN, bst_count(m->score_tree),  CLR_RESET,
           CLR_CYAN, m->score_tree ? bst_min(m->score_tree)->score : 0, CLR_RESET,
           CLR_CYAN, m->score_tree ? bst_max(m->score_tree)->score : 0, CLR_RESET,
           CLR_WALL, CLR_RESET);
    move_cursor(row++, 10);
    printf("%s╚══════════════════════════════════════╝%s", CLR_WALL, CLR_RESET);

    row++;
    move_cursor(row++, 10);
    printf("%s— Estrutura da BST (ASCII) —%s", CLR_PANEL_HDR, CLR_RESET);
    row++;
    printf("\033[%d;2H", row);
    bst_print_ascii(m->score_tree, 0, 0);
    row += bst_height(m->score_tree) + 2;

    if (m->score_history_count >= 2) {
        move_cursor(row++, 10);
        printf("%s— Comparacao dos 7 Sorts (us) —%s", CLR_PANEL_HDR, CLR_RESET);
        const char *nomes[7] = {
            "Bubble","Selection","Insertion","Shell","Merge","Quick","Heap"
        };
        long long melhor = m->sort_times[0]; int mi = 0;
        for (int i = 1; i < 7; i++)
            if (m->sort_times[i] > 0 && m->sort_times[i] < melhor) {
                melhor = m->sort_times[i]; mi = i;
            }
        for (int i = 0; i < 7; i++) {
            move_cursor(row++, 10);
            printf("  %s%-10s%s : %s%4lld us%s %s",
                   i == mi ? CLR_GREEN : CLR_DIM, nomes[i], CLR_RESET,
                   i == mi ? CLR_GREEN : CLR_CYAN,
                   m->sort_times[i], CLR_RESET,
                   i == mi ? "<- mais rapido" : "");
        }
    }

    row += 2;
    move_cursor(row, 10);
    printf("%s[ ESC / Q ] Voltar%s", CLR_DIM, CLR_RESET);
    view_flush();
}
/* ============================================================
 *  MAPA
 * ============================================================ */

void view_draw_cell(GameModel *m, int x, int y) {
    move_cursor(OFFSET_Y + y, OFFSET_X + x * CELL_W);
    if (m->grid[y][x] == TILE_PELLET) {
        printf("%s .%s", CLR_PELLET, CLR_RESET);
        return;
    }
    switch (m->grid[y][x]) {
        case TILE_WALL:
            printf("%s██%s", CLR_WALL, CLR_RESET);
            break;
        case TILE_PELLET:
            printf("%s · %s", CLR_PELLET, CLR_RESET);
            break;
        case TILE_POWER:
            if (m->frame_count % 6 < 3)
                printf("%s ●%s", CLR_POWER, CLR_RESET);
            else
                printf("  ");
            break;
        case TILE_DOOR:
            printf("%s══%s", CLR_DOOR, CLR_RESET);
            break;
        case TILE_TUNNEL:
            printf("%s  %s", CLR_DIM2, CLR_RESET);
            break;
        default:
            printf("  ");
            break;
    }
}

void view_draw_map(GameModel *m) {
    for (int y = 0; y < MAP_H; y++)
        for (int x = 0; x < MAP_W; x++)
            view_draw_cell(m, x, y);
}

/* ============================================================
 *  ENTIDADES
 * ============================================================ */

/* Animacao do Pac-Man com 4 frames por direcao */
static const char *pacman_sprite(GameModel *m) {
    static const char *aberto[4] = {"ᗒ ","◕ ","◉ ","◕ "};
    static const char *esq[4]    = {"ᗕ ","◔ ","◉ ","◔ "};
    static const char *cima[4]   = {"⊙ ","◔ ","◉ ","◔ "};
    static const char *baixo[4]  = {"⊙ ","◕ ","◉ ","◕ "};
    static const char *neutro[4] = {"◉ ","◎ ","○ ","◎ "};

    int f = (m->frame_count / 2) % 4;

    if (m->current_dx ==  1) return aberto[f];
    if (m->current_dx == -1) return esq[f];
    if (m->current_dy == -1) return cima[f];
    if (m->current_dy ==  1) return baixo[f];
    return neutro[f];
}

static const char *ghost_color(int idx, int vulnerable, int frame) {
    if (vulnerable)
        return (frame % 4 < 2) ? CLR_VULN : CLR_VULN2;
    switch (idx) {
        case 0: return CLR_BLINKY;
        case 1: return CLR_PINKY;
        case 2: return CLR_INKY;
        case 3: return CLR_CLYDE;
        default: return CLR_RESET;
    }
}

void view_erase_entities(GameModel *m) {
    move_cursor(OFFSET_Y + m->pacman.y, OFFSET_X + m->pacman.x * CELL_W);
    printf("  ");
    for (int i = 0; i < GHOSTS; i++) {
        move_cursor(OFFSET_Y + m->ghosts[i].e.y,
                    OFFSET_X + m->ghosts[i].e.x * CELL_W);
        printf("  ");
    }
}

void view_draw_entities(GameModel *m) {
    /* Fantasmas */
    for (int i = 0; i < GHOSTS; i++) {
        if (m->ghosts[i].in_house) continue;
        move_cursor(OFFSET_Y + m->ghosts[i].e.y,
                    OFFSET_X + m->ghosts[i].e.x * CELL_W);
        printf("%sᗣ %s",
               ghost_color(i, m->ghosts[i].vulnerable, m->frame_count),
               CLR_RESET);
    }
    /* Pac-Man */
    move_cursor(OFFSET_Y + m->pacman.y, OFFSET_X + m->pacman.x * CELL_W);
    printf("%s%s%s", CLR_PACMAN, pacman_sprite(m), CLR_RESET);

    /* Fruta bonus */
    if (m->fruit_active) {
        move_cursor(OFFSET_Y + m->fruit_y, OFFSET_X + m->fruit_x * CELL_W);
        printf("%s$*%s", CLR_TITLE, CLR_RESET);
    }
}

/* ============================================================
 *  HUD
 * ============================================================ */

void view_draw_hud(GameModel *m) {
    move_cursor(1, OFFSET_X);
    printf("%s PAC-MAN%s                                                  ", CLR_TITLE, CLR_RESET);

    move_cursor(2, OFFSET_X);
    printf("%sSCORE:%s %s%-8d%s  %sHIGH:%s %s%-8d%s                 ",
           CLR_DIM, CLR_RESET, CLR_SCORE, m->score, CLR_RESET,
           CLR_DIM, CLR_RESET, CLR_CYAN,  m->high_score, CLR_RESET);

    move_cursor(3, OFFSET_X);
    printf("%sNIVEL:%s %s%-3d%s  %sVIDAS:%s ",
           CLR_DIM, CLR_RESET, CLR_GREEN, m->level, CLR_RESET,
           CLR_DIM, CLR_RESET);
    for (int i = 0; i < m->lives; i++) printf("%s♥ %s", CLR_BLINKY, CLR_RESET);

    for (int i = m->lives; i < START_LIVES; i++) printf("  ");
    printf("                              ");

    /* Barra de progresso dos pellets */
    move_cursor(4, OFFSET_X);
    int coletados = m->total_pellets - m->pellets_left;
    int pct = m->total_pellets > 0 ? coletados * 100 / m->total_pellets : 0;
    int barras = pct / 5;
    printf("%sPellets:%s [", CLR_DIM, CLR_RESET);
    for (int i = 0; i < 20; i++) {
        if (i < barras) printf("%s█%s", CLR_GREEN, CLR_RESET);
        else            printf("%s░%s", CLR_DIM2,  CLR_RESET);
    }
    printf("] %s%3d%%%s  %s%d%s/%s%d%s",
           CLR_GREEN, pct, CLR_RESET,
           CLR_CYAN,  coletados, CLR_RESET,
           CLR_DIM,   m->total_pellets, CLR_RESET);

    move_cursor(5, OFFSET_X);
    if (m->auto_play) {
        printf("%s[AUTO]%s %s%-48s%s", CLR_AUTO_TAG, CLR_RESET,
               CLR_DIM, m->auto_status, CLR_RESET);
    } else {
        printf("                                                        ");
    }
}

/* ============================================================
 *  PAINEL LATERAL
 * ============================================================ */

static void view_clear_side_panel_area(void) {
    int col = OFFSET_X + MAP_W * CELL_W + 4;
    for (int row = OFFSET_Y; row < OFFSET_Y + MAP_H; row++) {
        move_cursor(row, col);
        printf("                              ");
    }
}

void view_draw_side_panel(GameModel *m) {
    int col = OFFSET_X + MAP_W * CELL_W + 4;
    int row = OFFSET_Y;

    view_clear_side_panel_area();

    move_cursor(row++, col);
    printf("%s┌──────────────────────┐%s", CLR_PANEL_BORDER, CLR_RESET);
    move_cursor(row++, col);
    printf("%s│%s %sESTRUTURAS DE DADOS%s   %s│%s",
           CLR_PANEL_BORDER, CLR_RESET, CLR_PANEL_HDR, CLR_RESET,
           CLR_PANEL_BORDER, CLR_RESET);
    move_cursor(row++, col);
    printf("%s├──────────────────────┤%s", CLR_PANEL_BORDER, CLR_RESET);

    /* BST */
    move_cursor(row++, col);
    printf("%s│%s %sBST High Scores%s       %s│%s",
           CLR_PANEL_BORDER, CLR_RESET, CLR_CYAN, CLR_RESET,
           CLR_PANEL_BORDER, CLR_RESET);
    move_cursor(row++, col);
    printf("%s│%s  Altura:%s%-3d%s Nos:%s%-3d%s  %s│%s",
           CLR_PANEL_BORDER, CLR_RESET,
           CLR_SCORE, bst_height(m->score_tree), CLR_RESET,
           CLR_SCORE, bst_count(m->score_tree),  CLR_RESET,
           CLR_PANEL_BORDER, CLR_RESET);
    BSTNode *mn = bst_min(m->score_tree);
    BSTNode *mx = bst_max(m->score_tree);
    move_cursor(row++, col);
    printf("%s│%s  Min:%s%-6d%s Max:%s%-5d%s%s│%s",
           CLR_PANEL_BORDER, CLR_RESET,
           CLR_DIM, mn ? mn->score : 0, CLR_RESET,
           CLR_DIM, mx ? mx->score : 0, CLR_RESET,
           CLR_PANEL_BORDER, CLR_RESET);
    move_cursor(row++, col);
    printf("%s├──────────────────────┤%s", CLR_PANEL_BORDER, CLR_RESET);

    /* AVL */
    move_cursor(row++, col);
    printf("%s│%s %sAVL Power-Ups%s         %s│%s",
           CLR_PANEL_BORDER, CLR_RESET, CLR_MAGENTA, CLR_RESET,
           CLR_PANEL_BORDER, CLR_RESET);
    move_cursor(row++, col);
    printf("%s│%s  BF raiz: %s%-3d%s           %s│%s",
           CLR_PANEL_BORDER, CLR_RESET,
           CLR_SCORE, avl_balance_factor(m->powerup_tree), CLR_RESET,
           CLR_PANEL_BORDER, CLR_RESET);
    move_cursor(row++, col);
    printf("%s│%s  Rot.S:%s%-3d%s Rot.D:%s%-3d%s  %s│%s",
           CLR_PANEL_BORDER, CLR_RESET,
           CLR_GREEN,  m->avl_rotations_simple, CLR_RESET,
           CLR_ORANGE, m->avl_rotations_double, CLR_RESET,
           CLR_PANEL_BORDER, CLR_RESET);
    move_cursor(row++, col);
    printf("%s├──────────────────────┤%s", CLR_PANEL_BORDER, CLR_RESET);

    /* Grafo */
    move_cursor(row++, col);
    printf("%s│%s %sGrafo Labirinto%s       %s│%s",
           CLR_PANEL_BORDER, CLR_RESET, CLR_INKY, CLR_RESET,
           CLR_PANEL_BORDER, CLR_RESET);
    move_cursor(row++, col);
    printf("%s│%s  Vertices:%s%-6d%s      %s│%s",
           CLR_PANEL_BORDER, CLR_RESET,
           CLR_CYAN, m->maze_graph ? m->maze_graph->num_vertices : 0, CLR_RESET,
           CLR_PANEL_BORDER, CLR_RESET);
    move_cursor(row++, col);
    printf("%s│%s  %sBlinky%s:Dijkstra       %s│%s",
           CLR_PANEL_BORDER, CLR_RESET, CLR_BLINKY, CLR_RESET,
           CLR_PANEL_BORDER, CLR_RESET);
    move_cursor(row++, col);
    printf("%s│%s  %sPinky%s :BFS            %s│%s",
           CLR_PANEL_BORDER, CLR_RESET, CLR_PINKY, CLR_RESET,
           CLR_PANEL_BORDER, CLR_RESET);
    move_cursor(row++, col);
    printf("%s│%s  %sInky%s  :DFS            %s│%s",
           CLR_PANEL_BORDER, CLR_RESET, CLR_INKY, CLR_RESET,
           CLR_PANEL_BORDER, CLR_RESET);
    move_cursor(row++, col);
    printf("%s│%s  %sClyde%s :Manhattan      %s│%s",
           CLR_PANEL_BORDER, CLR_RESET, CLR_CLYDE, CLR_RESET,
           CLR_PANEL_BORDER, CLR_RESET);
    move_cursor(row++, col);
    printf("%s├──────────────────────┤%s", CLR_PANEL_BORDER, CLR_RESET);

    /* Estatisticas dos algoritmos */
    move_cursor(row++, col);
    printf("%s│%s %sStats algoritmos%s      %s│%s",
           CLR_PANEL_BORDER, CLR_RESET, CLR_PANEL_HDR, CLR_RESET,
           CLR_PANEL_BORDER, CLR_RESET);
    move_cursor(row++, col);
    printf("%s│%s  BFS  nos:%s%-6d%s     %s│%s",
           CLR_PANEL_BORDER, CLR_RESET,
           CLR_CYAN, model_get_bfs_count(), CLR_RESET,
           CLR_PANEL_BORDER, CLR_RESET);
    move_cursor(row++, col);
    printf("%s│%s  DFS  nos:%s%-6d%s     %s│%s",
           CLR_PANEL_BORDER, CLR_RESET,
           CLR_CYAN, model_get_dfs_count(), CLR_RESET,
           CLR_PANEL_BORDER, CLR_RESET);
    move_cursor(row++, col);
    printf("%s│%s  Dijk nos:%s%-6d%s     %s│%s",
           CLR_PANEL_BORDER, CLR_RESET,
           CLR_CYAN, model_get_dijkstra_count(), CLR_RESET,
           CLR_PANEL_BORDER, CLR_RESET);

    /* Power timer */
    if (m->power_timer > 0) {
        move_cursor(row++, col);
        printf("%s├──────────────────────┤%s", CLR_PANEL_BORDER, CLR_RESET);
        move_cursor(row++, col);
        int bars = m->power_timer * 10 / POWER_TIME;
        printf("%s│%s %sPOWER:%s ", CLR_PANEL_BORDER, CLR_RESET, CLR_POWER, CLR_RESET);
        for (int i = 0; i < 10; i++)
            printf("%s%s%s", i < bars ? CLR_POWER : CLR_DIM2,
                   i < bars ? "█" : "░", CLR_RESET);
        printf(" %s│%s", CLR_PANEL_BORDER, CLR_RESET);
    }

    move_cursor(row++, col);
    printf("%s└──────────────────────┘%s", CLR_PANEL_BORDER, CLR_RESET);

    /* Conquistas no painel */
    row++;
    view_draw_achievements(m);

    /* Controles */
    row += 8;
    move_cursor(row++, col);
    printf("%s  ↑↓←→ Mover  P Pausa%s", CLR_DIM, CLR_RESET);
    move_cursor(row++, col);
    printf("%s  D Debug  TAB Auto  Q Sair%s", CLR_DIM, CLR_RESET);
}
/* ============================================================
 *  DEBUG OVERLAY — M06/P05 expandido
 * ============================================================ */

static void view_draw_debug_overlay(GameModel *m) {
    if (!debug_mode) return;

    /* Linha de info abaixo do mapa */
    int row = OFFSET_Y + MAP_H + 1;
    int col = OFFSET_X;

    move_cursor(row++, col);
    printf("%s[DEBUG]%s Pac(%d,%d) Score:%d Vidas:%d Frame:%d",
           CLR_GREEN, CLR_RESET,
           m->pacman.x, m->pacman.y,
           m->score, m->lives, m->frame_count);

    move_cursor(row++, col);
    printf("%sFantasmas:%s B(%d,%d) P(%d,%d) I(%d,%d) C(%d,%d)",
           CLR_DIM, CLR_RESET,
           m->ghosts[0].e.x, m->ghosts[0].e.y,
           m->ghosts[1].e.x, m->ghosts[1].e.y,
           m->ghosts[2].e.x, m->ghosts[2].e.y,
           m->ghosts[3].e.x, m->ghosts[3].e.y);

    move_cursor(row, col);
    printf("%sEDs:%s BST_h=%d AVL_h=%d Power=%d Pellets=%d/%d",
           CLR_DIM, CLR_RESET,
           bst_height(m->score_tree),
           avl_height(m->powerup_tree),
           m->power_timer,
           m->total_pellets - m->pellets_left,
           m->total_pellets);

    /* Overlay BFS no mapa */
    if (!m->maze_graph) return;
    for (int y = 0; y < MAP_H; y++) {
        for (int x = 0; x < MAP_W; x++) {
            if (m->grid[y][x] == TILE_WALL) continue;
            int v = model_coord_to_vertex(x, y);
            int d = m->bfs_dist[v];
            if (d == INF || d == 0) continue;
            move_cursor(OFFSET_Y + y, OFFSET_X + x * CELL_W);
            if      (d <= 5)  printf("%s%2d%s", CLR_GREEN, d, CLR_RESET);
            else if (d <= 12) printf("%s%2d%s", CLR_CYAN,  d, CLR_RESET);
            else              printf("%s%2d%s", CLR_DIM,   d, CLR_RESET);
        }
    }
}

/* ============================================================
 *  BONUS OVERLAY
 * ============================================================ */

void view_draw_bonus(GameModel *m) {
    if (m->bonus_timer <= 0) return;
    move_cursor(OFFSET_Y + m->bonus_y, OFFSET_X + m->bonus_x * CELL_W);
    printf("%s+%d%s", CLR_TITLE, m->bonus_points, CLR_RESET);
}

/* ============================================================
 *  DRAW GAME — funcao principal de desenho
 * ============================================================ */

void view_draw_game(GameModel *m) {
    static int last_panel_frame = -1000;
    static int last_panel_score = -1, last_panel_lives = -1, last_panel_level = -1;
    static int last_panel_pellets = -1, last_panel_power = -1, last_panel_auto = -1;
    static int last_panel_ach = -1;
    int panel_ach = m->ach_first_win + m->ach_score_5000 * 2 +
                    m->ach_ate_4_ghosts * 4 + m->ach_pellet_master * 8;
    int panel_dirty = 0;

    view_draw_hud(m);

    if (!frame_cache_initialized || m->frame_count <= 1) {
        frame_cache_initialized = 1;
    } else {
        view_draw_cell(m, prev_pac_x, prev_pac_y);

        for (int i = 0; i < GHOSTS; i++) {
            if (prev_ghost_visible[i])
                view_draw_cell(m, prev_ghost_x[i], prev_ghost_y[i]);
        }

        if (prev_fruit_active)
            view_draw_cell(m, prev_fruit_x, prev_fruit_y);

        if (prev_bonus_active) {
            for (int x = prev_bonus_x; x <= prev_bonus_x + 2 && x < MAP_W; x++)
                view_draw_cell(m, x, prev_bonus_y);
        }
    }

    if (!frame_cache_initialized ||
        m->frame_count - last_panel_frame >= 6 ||
        m->score != last_panel_score ||
        m->lives != last_panel_lives ||
        m->level != last_panel_level ||
        m->pellets_left != last_panel_pellets ||
        m->auto_play != last_panel_auto ||
        panel_ach != last_panel_ach ||
        (last_panel_power > 0 && m->power_timer == 0) ||
        (m->power_timer > 0 && m->power_timer % 5 == 0)) {
        panel_dirty = 1;
    }

    if (panel_dirty) {
        view_draw_side_panel(m);
        last_panel_frame = m->frame_count;
        last_panel_score = m->score;
        last_panel_lives = m->lives;
        last_panel_level = m->level;
        last_panel_pellets = m->pellets_left;
        last_panel_power = m->power_timer;
        last_panel_auto = m->auto_play;
        last_panel_ach = panel_ach;
    }
    view_draw_debug_overlay(m);
    view_draw_entities(m);
    view_draw_bonus(m);

    prev_pac_x = m->pacman.x;
    prev_pac_y = m->pacman.y;
    for (int i = 0; i < GHOSTS; i++) {
        prev_ghost_x[i] = m->ghosts[i].e.x;
        prev_ghost_y[i] = m->ghosts[i].e.y;
        prev_ghost_visible[i] = !m->ghosts[i].in_house;
    }
    prev_fruit_active = m->fruit_active;
    prev_fruit_x = m->fruit_x;
    prev_fruit_y = m->fruit_y;
    prev_bonus_active = m->bonus_timer > 0;
    prev_bonus_x = m->bonus_x;
    prev_bonus_y = m->bonus_y;

    view_flush();
}

/* ============================================================
 *  MENSAGENS DE ESTADO
 * ============================================================ */

void view_draw_ready(void) {
    int row = OFFSET_Y + MAP_H / 2;
    int col = OFFSET_X + MAP_W * CELL_W / 2 - 5;
    move_cursor(row, col);
    printf("%s  READY!  %s", CLR_READY, CLR_RESET);
    view_flush();
}

void view_clear_ready(GameModel *m) {
    int row = OFFSET_Y + MAP_H / 2;
    int col = OFFSET_X + MAP_W * CELL_W / 2 - 5;
    int y = row - OFFSET_Y;
    int x_start = (col - OFFSET_X) / CELL_W;
    int x_end = (col + 8 - OFFSET_X) / CELL_W;

    if (x_start < 0) x_start = 0;
    if (x_end >= MAP_W) x_end = MAP_W - 1;

    for (int x = x_start; x <= x_end; x++)
        view_draw_cell(m, x, y);

    view_reset_frame_cache();
    view_flush();
}

void view_draw_gameover(GameModel *m) {
    int row = OFFSET_Y + MAP_H / 2 - 1;
    int col = OFFSET_X + MAP_W * CELL_W / 2 - 8;
    move_cursor(row,   col); printf("%s ╔══════════════╗ %s", CLR_GAMEOVER, CLR_RESET);
    move_cursor(row+1, col); printf("%s ║  GAME  OVER  ║ %s", CLR_GAMEOVER, CLR_RESET);
    move_cursor(row+2, col); printf("%s ║  Score:%-6d║ %s", CLR_SCORE, m->score, CLR_RESET);
    move_cursor(row+3, col); printf("%s ╚══════════════╝ %s", CLR_GAMEOVER, CLR_RESET);
    view_flush();
}

void view_draw_win(GameModel *m) {
    int row = OFFSET_Y + MAP_H / 2 - 1;
    int col = OFFSET_X + MAP_W * CELL_W / 2 - 8;
    move_cursor(row,   col); printf("%s ╔══════════════╗ %s", CLR_WIN_CLR, CLR_RESET);
    move_cursor(row+1, col); printf("%s ║  LEVEL  WIN! ║ %s", CLR_WIN_CLR, CLR_RESET);
    move_cursor(row+2, col); printf("%s ║  Score:%-6d║ %s", CLR_SCORE, m->score, CLR_RESET);
    move_cursor(row+3, col); printf("%s ╚══════════════╝ %s", CLR_WIN_CLR, CLR_RESET);
    view_flush();
}

/* Banner de nivel */
void view_draw_level_banner(GameModel *m) {
    int row = OFFSET_Y + MAP_H / 2 + 2;
    int col = OFFSET_X + MAP_W * CELL_W / 2 - 8;
    move_cursor(row, col);
    printf("%s  ★  LEVEL %d  ★  %s", CLR_WIN_CLR, m->level, CLR_RESET);
    view_flush();
}

/* Animacao de morte */
void view_draw_death_anim(GameModel *m, int frame) {
    static const char *frames[] = {"◉ ","⊙ ","◎ ","○ ","· ","  "};
    int f = (frame / 3) % 6;
    move_cursor(OFFSET_Y + m->pacman.y, OFFSET_X + m->pacman.x * CELL_W);
    printf("%s%s%s", CLR_PACMAN, frames[f], CLR_RESET);
    view_flush();
}

/* ============================================================
 *  M07 — TELA DE PAUSA
 * ============================================================ */

void view_draw_pause(GameModel *m) {
    int row = OFFSET_Y + 4;
    int col = OFFSET_X + MAP_W * CELL_W / 2 - 15;

    move_cursor(row++, col);
    printf("%s╔═════════════════════════════╗%s", CLR_PANEL_BORDER, CLR_RESET);
    move_cursor(row++, col);
    printf("%s║%s       JOGO PAUSADO           %s║%s",
           CLR_PANEL_BORDER, CLR_TITLE, CLR_PANEL_BORDER, CLR_RESET);
    move_cursor(row++, col);
    printf("%s╠═════════════════════════════╣%s", CLR_PANEL_BORDER, CLR_RESET);
    move_cursor(row++, col);
    printf("%s║%s  Score : %s%-8d%s             %s║%s",
           CLR_PANEL_BORDER, CLR_RESET, CLR_SCORE, m->score, CLR_RESET,
           CLR_PANEL_BORDER, CLR_RESET);
    move_cursor(row++, col);
    printf("%s║%s  Vidas : %s%-3d%s                  %s║%s",
           CLR_PANEL_BORDER, CLR_RESET, CLR_GREEN, m->lives, CLR_RESET,
           CLR_PANEL_BORDER, CLR_RESET);
    move_cursor(row++, col);
    printf("%s║%s  Nivel : %s%-3d%s                  %s║%s",
           CLR_PANEL_BORDER, CLR_RESET, CLR_CYAN, m->level, CLR_RESET,
           CLR_PANEL_BORDER, CLR_RESET);
    move_cursor(row++, col);
    printf("%s║%s  Pellets: %s%-4d%s restantes     %s║%s",
           CLR_PANEL_BORDER, CLR_RESET, CLR_PELLET, m->pellets_left, CLR_RESET,
           CLR_PANEL_BORDER, CLR_RESET);
    move_cursor(row++, col);
    printf("%s╠═════════════════════════════╣%s", CLR_PANEL_BORDER, CLR_RESET);
    move_cursor(row++, col);
    printf("%s║%s  BST h:%s%d%s nos:%s%d%s              %s║%s",
           CLR_PANEL_BORDER, CLR_RESET,
           CLR_CYAN, bst_height(m->score_tree), CLR_RESET,
           CLR_CYAN, bst_count(m->score_tree),  CLR_RESET,
           CLR_PANEL_BORDER, CLR_RESET);
    move_cursor(row++, col);
    printf("%s║%s  AVL rot.S:%s%d%s rot.D:%s%d%s        %s║%s",
           CLR_PANEL_BORDER, CLR_RESET,
           CLR_GREEN,  m->avl_rotations_simple, CLR_RESET,
           CLR_ORANGE, m->avl_rotations_double, CLR_RESET,
           CLR_PANEL_BORDER, CLR_RESET);
    move_cursor(row++, col);
    printf("%s╠═════════════════════════════╣%s", CLR_PANEL_BORDER, CLR_RESET);
    move_cursor(row++, col);
    printf("%s║%s  P Continuar    Q Sair       %s║%s",
           CLR_PANEL_BORDER, CLR_DIM, CLR_PANEL_BORDER, CLR_RESET);
    move_cursor(row, col);
    printf("%s╚═════════════════════════════╝%s", CLR_PANEL_BORDER, CLR_RESET);
    view_flush();
}

/* ============================================================
 *  M08 — TELA DE AJUDA
 * ============================================================ */

void view_draw_help(GameModel *m) {
    (void)m;
    view_clear();
    int row = 2;

    move_cursor(row++, 6);
    printf("%s╔══════════════════════════════════════════════╗%s", CLR_WALL, CLR_RESET);
    move_cursor(row++, 6);
    printf("%s║%s     GUIA DAS ESTRUTURAS DE DADOS             %s║%s",
           CLR_WALL, CLR_TITLE, CLR_WALL, CLR_RESET);
    move_cursor(row++, 6);
    printf("%s╠══════════════════════════════════════════════╣%s", CLR_WALL, CLR_RESET);

    move_cursor(row++, 6);
    printf("%s║%s %sBST — Arvore Binaria de Busca%s               %s║%s",
           CLR_WALL, CLR_RESET, CLR_CYAN, CLR_RESET, CLR_WALL, CLR_RESET);
    move_cursor(row++, 6);
    printf("%s║%s  Armazena high scores. Insert/search O(log n) %s║%s",
           CLR_WALL, CLR_DIM, CLR_WALL, CLR_RESET);
    move_cursor(row++, 6);
    printf("%s║%s  In-order retorna scores do menor ao maior.   %s║%s",
           CLR_WALL, CLR_DIM, CLR_WALL, CLR_RESET);
    move_cursor(row++, 6);
    printf("%s╠══════════════════════════════════════════════╣%s", CLR_WALL, CLR_RESET);

    move_cursor(row++, 6);
    printf("%s║%s %sAVL — Arvore Balanceada%s                     %s║%s",
           CLR_WALL, CLR_RESET, CLR_MAGENTA, CLR_RESET, CLR_WALL, CLR_RESET);
    move_cursor(row++, 6);
    printf("%s║%s  Inventario de power-ups. O(log n) garantido. %s║%s",
           CLR_WALL, CLR_DIM, CLR_WALL, CLR_RESET);
    move_cursor(row++, 6);
    printf("%s║%s  Rotacoes LL/RR (simples) e LR/RL (duplas).   %s║%s",
           CLR_WALL, CLR_DIM, CLR_WALL, CLR_RESET);
    move_cursor(row++, 6);
    printf("%s╠══════════════════════════════════════════════╣%s", CLR_WALL, CLR_RESET);

    move_cursor(row++, 6);
    printf("%s║%s %sGrafo — Labirinto (Matriz + Lista Adj.)%s     %s║%s",
           CLR_WALL, CLR_RESET, CLR_INKY, CLR_RESET, CLR_WALL, CLR_RESET);
    move_cursor(row++, 6);
    printf("%s║%s  %sBlinky%s Dijkstra | %sPinky%s BFS | %sInky%s DFS      %s║%s",
           CLR_WALL, CLR_RESET,
           CLR_BLINKY, CLR_RESET, CLR_PINKY, CLR_RESET,
           CLR_INKY, CLR_RESET, CLR_WALL, CLR_RESET);
    move_cursor(row++, 6);
    printf("%s╠══════════════════════════════════════════════╣%s", CLR_WALL, CLR_RESET);

    move_cursor(row++, 6);
    printf("%s║%s %s7 Sorts%s — comparados em microsegundos        %s║%s",
           CLR_WALL, CLR_RESET, CLR_ORANGE, CLR_RESET, CLR_WALL, CLR_RESET);
    move_cursor(row++, 6);
    printf("%s║%s  Bubble/Selection/Insertion/Shell             %s║%s",
           CLR_WALL, CLR_DIM, CLR_WALL, CLR_RESET);
    move_cursor(row++, 6);
    printf("%s║%s  Merge/Quick/Heap                             %s║%s",
           CLR_WALL, CLR_DIM, CLR_WALL, CLR_RESET);
    move_cursor(row++, 6);
    printf("%s╠══════════════════════════════════════════════╣%s", CLR_WALL, CLR_RESET);

    move_cursor(row++, 6);
    printf("%s║%s %sCONTROLES%s                                    %s║%s",
           CLR_WALL, CLR_RESET, CLR_GREEN, CLR_RESET, CLR_WALL, CLR_RESET);
    move_cursor(row++, 6);
    printf("%s║%s  ↑↓←→/WASD Mover   P Pausar                  %s║%s",
           CLR_WALL, CLR_DIM, CLR_WALL, CLR_RESET);
    move_cursor(row++, 6);
    printf("%s║%s  D Debug BFS/info  TAB Auto-play  Q Sair      %s║%s",
           CLR_WALL, CLR_DIM, CLR_WALL, CLR_RESET);
    move_cursor(row++, 6);
    printf("%s╚══════════════════════════════════════════════╝%s", CLR_WALL, CLR_RESET);

    row++;
    move_cursor(row, 6);
    printf("%s[ ESC / Q ] Voltar%s", CLR_DIM, CLR_RESET);
    view_flush();
}

/* ============================================================
 *  CONQUISTAS
 * ============================================================ */

void view_draw_achievements(GameModel *m) {
    int col = OFFSET_X + MAP_W * CELL_W + 4;
    int row = OFFSET_Y + 20;

    move_cursor(row++, col);
    printf("%s┌──────────────────────┐%s", CLR_PANEL_BORDER, CLR_RESET);
    move_cursor(row++, col);
    printf("%s│%s %sCONQUISTAS%s            %s│%s",
           CLR_PANEL_BORDER, CLR_RESET, CLR_TITLE, CLR_RESET,
           CLR_PANEL_BORDER, CLR_RESET);
    move_cursor(row++, col);
    printf("%s│%s %s%s%s Primeira Vitoria     %s│%s",
           CLR_PANEL_BORDER, CLR_RESET,
           m->ach_first_win    ? CLR_GREEN : CLR_DIM2,
           m->ach_first_win    ? "★" : "☆", CLR_RESET,
           CLR_PANEL_BORDER, CLR_RESET);
    move_cursor(row++, col);
    printf("%s│%s %s%s%s 5000 Pontos          %s│%s",
           CLR_PANEL_BORDER, CLR_RESET,
           m->ach_score_5000   ? CLR_GREEN : CLR_DIM2,
           m->ach_score_5000   ? "★" : "☆", CLR_RESET,
           CLR_PANEL_BORDER, CLR_RESET);
    move_cursor(row++, col);
    printf("%s│%s %s%s%s Comeu 4 Fantasmas    %s│%s",
           CLR_PANEL_BORDER, CLR_RESET,
           m->ach_ate_4_ghosts ? CLR_GREEN : CLR_DIM2,
           m->ach_ate_4_ghosts ? "★" : "☆", CLR_RESET,
           CLR_PANEL_BORDER, CLR_RESET);
    move_cursor(row++, col);
    printf("%s│%s %s%s%s Mestre dos Pellets   %s│%s",
           CLR_PANEL_BORDER, CLR_RESET,
           m->ach_pellet_master ? CLR_GREEN : CLR_DIM2,
           m->ach_pellet_master ? "★" : "☆", CLR_RESET,
           CLR_PANEL_BORDER, CLR_RESET);
    move_cursor(row, col);
    printf("%s└──────────────────────┘%s", CLR_PANEL_BORDER, CLR_RESET);
}
