/*
 * ============================================================
 *  CONTROLLER — Input do usuario e atualizacao de estado
 * ============================================================
 *  BUG5 corrigido: teclas H e S estavam com states trocados
 *
 *  Features implementadas:
 *  - P02: pede nome do jogador apos game over
 *  - Auto-play via BFS
 *  - Sistema de niveis com velocidade crescente
 *  - Fruta bonus
 *  - Conquistas
 *  - Debug expandido
 * ============================================================
 */

#include "pacman.h"

/* Declaracoes das funcoes de view que nao estao no header publico */

void view_set_debug(int on);
int  view_get_debug(void);
void view_draw_pause(GameModel *m);
void view_draw_level_banner(GameModel *m);
void view_reset_frame_cache(void);

static int gameover_name_asked = 0;

/* ============================================================
 *  P02 — Pede nome do jogador
 * ============================================================ */

static void show_cursor_temp(void) { printf("\033[?25h"); fflush(stdout); }

char *controller_ask_name(void) {
    static char name[16];

#ifndef _WIN32
    /* Restaura terminal para modo normal */
    struct termios cooked;
    tcgetattr(STDIN_FILENO, &cooked);
    cooked.c_lflag |= (ECHO | ICANON);
    tcsetattr(STDIN_FILENO, TCSANOW, &cooked);
    int flags = fcntl(STDIN_FILENO, F_GETFL, 0);
    fcntl(STDIN_FILENO, F_SETFL, flags & ~O_NONBLOCK);
#endif

    show_cursor_temp();
    printf("\n%s  Digite seu nome (max 15 chars): %s", CLR_TITLE, CLR_RESET);
    fflush(stdout);

    if (fgets(name, sizeof(name), stdin)) {
        int len = strlen(name);
        if (len > 0 && name[len-1] == '\n') name[len-1] = '\0';
        if (strlen(name) == 0) strncpy(name, "???", 15);
    } else {
        strncpy(name, "???", 15);
    }

#ifndef _WIN32
    /* Restaura modo raw */
    struct termios raw;
    tcgetattr(STDIN_FILENO, &raw);
    raw.c_lflag &= ~(ECHO | ICANON);
    raw.c_cc[VMIN]  = 0;
    raw.c_cc[VTIME] = 0;
    tcsetattr(STDIN_FILENO, TCSANOW, &raw);
    fcntl(STDIN_FILENO, F_SETFL, flags | O_NONBLOCK);
#endif

    return name;
}

/* ============================================================
 *  INPUT DO MENU
 *  BUG5 CORRIGIDO: H = Help, S = Scores
 * ============================================================ */

void controller_menu_input(GameModel *m) {
    if (!kbhit_custom()) return;
    int old_selected = m->menu_selected;
    int old_map = m->map_selected;
    int ch = getch_custom();

    /* Setas */
    if (ch == '\033') {
        getch_custom(); /* '[' */
        int arrow = getch_custom();
        if (arrow == 'A' && m->menu_selected > 0) m->menu_selected--;
        if (arrow == 'B' && m->menu_selected < 3) m->menu_selected++;
        if (arrow == 'C')
            m->map_selected = (m->map_selected + 1) % MAP_COUNT;
        if (arrow == 'D')
            m->map_selected = (m->map_selected + MAP_COUNT - 1) % MAP_COUNT;
        if (old_selected != m->menu_selected || old_map != m->map_selected)
            view_draw_menu(m);
        return;
    }

    /* Navegacao K/J */
    if ((ch == 'k' || ch == 'K') && m->menu_selected > 0) m->menu_selected--;
    if ((ch == 'j' || ch == 'J') && m->menu_selected < 3) m->menu_selected++;

    /* Enter ou espaco confirma */
    if (ch == '\n' || ch == '\r' || ch == ' ') {
        switch (m->menu_selected) {
            case 0: /* JOGAR */
                model_load_map(m);
                m->score = 0;
                m->lives = START_LIVES;
                m->level = 1;
                gameover_name_asked = 0;
                m->state = STATE_PLAYING;
                view_clear();
                view_draw_map(m);
                view_reset_frame_cache();
                view_draw_ready();
                sleep_ms(1500);
                view_clear_ready(m);
                break;
            case 1: /* SCORES */
                model_run_all_sorts(m);
                m->state = STATE_SCORES;
                break;
            case 2: /* AJUDA — BUG5 CORRIGIDO */
                m->state = STATE_HELP;
                break;
            case 3: /* SAIR */
                m->state   = STATE_QUIT;
                m->running = 0;
                break;
        }
        return;
    }

    /* Atalhos diretos */
    if (ch == 'q' || ch == 'Q') { m->state = STATE_QUIT; m->running = 0; }

    /* BUG5 CORRIGIDO: H = Help, S = Scores */
    if (ch == 'h' || ch == 'H') m->state = STATE_HELP;
    if (ch == 's' || ch == 'S') { model_run_all_sorts(m); m->state = STATE_SCORES; }

    if (m->state == STATE_MENU &&
        (old_selected != m->menu_selected || old_map != m->map_selected))
        view_draw_menu(m);
}

static void controller_secondary_screen_input(GameModel *m) {
    if (!kbhit_custom()) return;
    int ch = getch_custom();

    if (ch == '\033') {
        m->state = STATE_MENU;
        return;
    }

    if (ch == 'q' || ch == 'Q' || ch == '\n' || ch == '\r') {
        m->state = STATE_MENU;
    }
}

/* ============================================================
 *  INPUT DURANTE O JOGO
 * ============================================================ */

void controller_handle_input(GameModel *m) {
    if (m->state == STATE_MENU) {
        controller_menu_input(m);
        return;
    }

    if (m->state == STATE_SCORES || m->state == STATE_HELP) {
        controller_secondary_screen_input(m);
        return;
    }

    if (!kbhit_custom()) return;
    int ch = getch_custom();

    /* Sequencia de escape (setas) */
    if (ch == '\033') {
        int next = getch_custom();
        if (next == '[') {
            int arrow = getch_custom();
            switch (arrow) {
                case 'A': m->desired_dy = -1; m->desired_dx =  0; break;
                case 'B': m->desired_dy =  1; m->desired_dx =  0; break;
                case 'C': m->desired_dx =  1; m->desired_dy =  0; break;
                case 'D': m->desired_dx = -1; m->desired_dy =  0; break;
            }
        } else {
            /* ESC sozinho: volta ao menu */
            if (m->state == STATE_SCORES || m->state == STATE_HELP)
                m->state = STATE_MENU;
        }
        return;
    }

    switch (ch) {
        /* Movimento WASD */
        case 'w': case 'W':
            m->desired_dy = -1; m->desired_dx = 0; break;
        case 's': case 'S':
            m->desired_dy =  1; m->desired_dx = 0; break;
        case 'a': case 'A':
            m->desired_dx = -1; m->desired_dy = 0; break;

        /* D: debug durante jogo, movimento durante menu */
        case 'd': case 'D':
            if (m->state == STATE_PLAYING) {
                int novo = !view_get_debug();
                view_set_debug(novo);
                /* Popula distancias BFS para overlay */
                if (novo && m->maze_graph) {
                    int src = model_coord_to_vertex(m->pacman.x, m->pacman.y);
                    bfs(m->maze_graph, src, m->bfs_dist, m->bfs_prev);
                }
            } else {
                m->desired_dx = 1; m->desired_dy = 0;
            }
            break;

        /* Pausa */
        case 'p': case 'P':
            if (m->state == STATE_PLAYING) {
                m->state = STATE_PAUSED;
                view_draw_pause(m);
            } else if (m->state == STATE_PAUSED) {
                m->state = STATE_PLAYING;
                view_clear();
                view_draw_map(m);
                view_reset_frame_cache();
            }
            break;

        /* TAB: toggle auto-play */
        case '\t':
            m->auto_play = !m->auto_play;
            strncpy(m->auto_status,
                    m->auto_play ? "BFS ativo" : "Manual", 63);
            break;

        /* Sair */
        case 'q': case 'Q':
            m->state   = STATE_QUIT;
            m->running = 0;
            break;

        /* ESC: volta ao menu em telas secundarias */
        case 27:
            if (m->state == STATE_SCORES || m->state == STATE_HELP)
                m->state = STATE_MENU;
            break;

        /* Enter: avanca apos game over ou win */
        case '\n': case '\r':
            if (m->state == STATE_GAMEOVER || m->state == STATE_WIN) {
                m->state = STATE_MENU;
                view_clear();
                view_draw_menu(m);
            }
            break;
    }
}

/* ============================================================
 *  AUTO-PLAY — BFS busca o pellet mais proximo
 * ============================================================ */

void controller_auto_play(GameModel *m) {
    if (!m->maze_graph) return;

    int src = model_coord_to_vertex(m->pacman.x, m->pacman.y);
    bfs(m->maze_graph, src, m->bfs_dist, m->bfs_prev);

    /* Pellet ou power mais proximo */
    int best_dist = INF, best_v = -1;
    for (int y = 0; y < MAP_H; y++) {
        for (int x = 0; x < MAP_W; x++) {
            if (m->grid[y][x] == TILE_PELLET ||
                m->grid[y][x] == TILE_POWER) {
                int v = model_coord_to_vertex(x, y);
                if (m->bfs_dist[v] < best_dist) {
                    best_dist = m->bfs_dist[v];
                    best_v    = v;
                }
            }
        }
    }

    if (best_v < 0) return;

    /* Reconstroi o primeiro passo do caminho */
    int cur = best_v;
    while (cur != -1 && m->bfs_prev[cur] != src &&
           m->bfs_prev[cur] != -1)
        cur = m->bfs_prev[cur];

    if (cur < 0 || m->bfs_prev[cur] != src) return;

    int nx, ny;
    model_vertex_to_coord(cur, &nx, &ny);
    m->desired_dx = nx - m->pacman.x;
    m->desired_dy = ny - m->pacman.y;

    /* Corrige wrap do tunel */
    if (m->desired_dx >  1) m->desired_dx = -1;
    if (m->desired_dx < -1) m->desired_dx =  1;

    snprintf(m->auto_status, 63, "BFS dist=%d", best_dist);
}
/* ============================================================
 *  UPDATE — atualiza estado a cada frame
 * ============================================================ */

void controller_update(GameModel *m) {
    switch (m->state) {

        case STATE_MENU:
        case STATE_SCORES:
        case STATE_HELP:
        case STATE_PAUSED:
            break;

        case STATE_PLAYING: {
            m->frame_count++;

            /* Decrementa power timer */
            if (m->power_timer > 0) {
                m->power_timer--;
                if (m->power_timer == 0) {
                    for (int i = 0; i < GHOSTS; i++) {
                        m->ghosts[i].vulnerable = 0;
                        m->ghosts[i].eaten      = 0;
                    }
                    m->ghost_eat_combo = 0;
                }
            }

            /* Decrementa bonus overlay */
            if (m->bonus_timer > 0) m->bonus_timer--;

            /* Aguarda ready timer */
            if (m->ready_timer > 0) { m->ready_timer--; break; }

            /* Auto-play */
            if (m->auto_play) controller_auto_play(m);

            /* Move Pac-Man */
            model_move_pacman(m);

            /* Fruta bonus */
            model_update_fruit(m);

            /* Conquistas */
            model_check_achievements(m);

            /* Move fantasmas conforme velocidade do nivel */
            if (m->frame_count % m->ghost_speed_mod == 0)
                model_move_ghosts(m);

            /* Colisoes */
            int col = model_check_collisions(m);
            if (col > 0) {
                m->bonus_points = col;
                m->bonus_x      = m->pacman.x;
                m->bonus_y      = m->pacman.y;
                m->bonus_timer  = 12;
            }

            /* Vitoria: todos os pellets coletados */
            if (m->pellets_left == 0) {
                /* Conquistas de vitoria */
                m->ach_first_win = 1;
                if (m->lives == m->ach_lives_intact)
                    m->ach_pellet_master = 1;

                view_draw_win(m);
                view_draw_level_banner(m);
                sleep_ms(2500);

                /* Avanca nivel */
                m->level++;
                m->score += m->level * 1000;
                model_load_map(m);
                m->state = STATE_PLAYING;
                view_clear();
                view_draw_map(m);
                view_reset_frame_cache();
                view_draw_ready();
                sleep_ms(1500);
                view_clear_ready(m);
            }
            break;
        }

        case STATE_DYING: {
            m->death_anim++;
            view_draw_death_anim(m, m->death_anim);
            sleep_ms(120);
            if (m->death_anim >= 18) {
                if (m->lives > 0) {
                    model_reset_positions(m);
                    m->state = STATE_PLAYING;
                    view_clear();
                    view_draw_map(m);
                    view_reset_frame_cache();
                    view_draw_ready();
                    sleep_ms(1200);
                    view_clear_ready(m);
                } else {
                    m->state = STATE_GAMEOVER;
                }
            }
            break;
        }

        case STATE_GAMEOVER: {
            /* Pede nome apenas uma vez por partida */
            if (!gameover_name_asked) {
                view_draw_gameover(m);

                /* Restaura terminal para digitar */
                view_cleanup();
                char *name = controller_ask_name();
                strncpy(m->player_name, name, 15);
                view_init();

                /* Atualiza BST com nome correto */
                m->score_tree = bst_remove(m->score_tree, m->score);
                m->score_tree = bst_insert(m->score_tree,
                                           m->score, m->player_name);
                model_save_scores(m);
                model_run_all_sorts(m);

                /* Relatorio final */
                view_cleanup();
                model_print_final_report(m);
                sleep_ms(500);
                view_init();

                gameover_name_asked = 1;
                view_clear();
                view_draw_gameover(m);
            }
            break;
        }

        case STATE_WIN:
            /* Tratado dentro de STATE_PLAYING */
            break;

        case STATE_QUIT:
            m->running = 0;
            break;

        default:
            break;
    }
}

/* ============================================================
 *  LOOP PRINCIPAL — padrao MVC: input → update → draw
 * ============================================================ */

void controller_run(GameModel *m) {
    view_init();
    model_init(m);

    if (!m->splash_shown)
        view_draw_splash(m);

    view_draw_menu(m);

    while (m->running) {
        /* 1. Input */
        controller_handle_input(m);

        /* 2. Update */
        controller_update(m);

        /* 3. Draw */
        switch (m->state) {
            case STATE_MENU:
                break;

            case STATE_PLAYING:
                view_draw_game(m);
                break;

            case STATE_PAUSED:
                /* Ja desenhado no handle_input */
                break;

            case STATE_SCORES:
                view_draw_scores(m);
                while (m->state == STATE_SCORES) {
                    controller_handle_input(m);
                    sleep_ms(50);
                }
                view_clear();
                view_draw_menu(m);
                break;

            case STATE_HELP:
                view_draw_help(m);
                while (m->state == STATE_HELP) {
                    controller_handle_input(m);
                    sleep_ms(50);
                }
                view_clear();
                view_draw_menu(m);
                break;

            case STATE_DYING:
                /* Animacao tratada no update */
                break;

            case STATE_GAMEOVER:
                if (m->state == STATE_MENU) {
                    m->score = 0;
                    m->lives = START_LIVES;
                    m->level = 1;
                    gameover_name_asked = 0;
                    view_clear();
                    view_draw_menu(m);
                }
                break;

            case STATE_WIN:
                break;

            case STATE_QUIT:
                m->running = 0;
                break;

            default:
                break;
        }

        sleep_ms(FRAME_MS);
    }

    /* Limpeza final */
    view_cleanup();
    model_free(m);
    
}
