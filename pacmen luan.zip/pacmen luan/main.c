
/*
 * ============================================================
 *  main.c — Ponto de entrada do PAC-MAN
 * ============================================================
 *  Apenas instancia o GameModel e inicia o controller.
 *  Toda a logica fica em model.c, view.c e controller.c.
 * ============================================================
 */

#include "pacman.h"

int main(void) {
    /* Inicializa semente aleatoria para fruta e IA */
    srand((unsigned int)time(NULL));

    /* Instancia o model na stack (zerando tudo) */
    GameModel model;
    memset(&model, 0, sizeof(GameModel));

    /* Inicia o loop principal MVC */
    controller_run(&model);

    return 0;
}